package app.zerogram.feature.chat

import android.net.Uri
import androidx.compose.runtime.Immutable
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.ImmutableSet
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.persistentSetOf

@Immutable
sealed interface BubbleMediaUi {
    @Immutable
    data class Text(
        val text: String,
    ) : BubbleMediaUi

    @Immutable
    data class Photo(
        val fileId: Int,
        val localPath: String?,
        val aspectRatio: Float,
        val caption: String,
        val isDownloading: Boolean,
    ) : BubbleMediaUi

    @Immutable
    data class Voice(
        val fileId: Int,
        val localPath: String?,
        val durationSeconds: Int,
        val durationLabel: String,
        val waveformSamples: ImmutableList<Float>,
        val isDownloading: Boolean,
    ) : BubbleMediaUi

    @Immutable
    data class Sticker(
        val stickerFileId: Int,
        val staticPreviewFileId: Int,
        val staticPreviewLocalPath: String?,
        val animatedLocalPath: String?,
        val emoji: String,
        val isAnimatedFormat: Boolean,
    ) : BubbleMediaUi

    @Immutable
    data class DocumentFile(
        val fileId: Int,
        val localPath: String?,
        val fileName: String,
        val sizeLabel: String,
        val isDownloading: Boolean,
    ) : BubbleMediaUi

    @Immutable
    data class VideoNoteTappedOnly(
        val durationLabel: String,
    ) : BubbleMediaUi
}

@Immutable
data class MessageBubbleUi(
    val id: Long,
    val senderName: String?,
    val isOutgoing: Boolean,
    val formattedTime: String,
    val statusBadge: String,
    val media: BubbleMediaUi,
)

@Immutable
data class ChatUiState(
    val chatId: Long,
    val title: String,
    val inputText: String = "",
    val instantSeedMessages: ImmutableList<MessageBubbleUi> = persistentListOf(),
    val voicePlayback: VoicePlaybackState = VoicePlaybackState(),
    val tappedStickerIds: ImmutableSet<Long> = persistentSetOf(),
)

sealed interface ChatIntent {
    data class InputChanged(val text: String) : ChatIntent
    data object SendText : ChatIntent
    data class SendPickedPhoto(val uri: Uri) : ChatIntent
    data class ClickVoice(val messageId: Long, val fileId: Int, val localPath: String?) : ChatIntent
    data object CycleVoiceSpeed : ChatIntent
    data class ClickSticker(val messageId: Long, val stickerFileId: Int, val isAnimatedFormat: Boolean) : ChatIntent
    data class ClickDocument(val fileId: Int, val localPath: String?) : ChatIntent
    data class ClickPhoto(val fileId: Int, val localPath: String?) : ChatIntent
}
