package app.zerogram.feature.chat

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import androidx.compose.runtime.Immutable
import app.zerogram.core.common.AppDispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@Immutable
data class VoicePlaybackState(
    val activeMessageId: Long? = null,
    val isPlaying: Boolean = false,
    val progressFraction: Float = 0f,
    val elapsedSeconds: Int = 0,
    val playbackSpeed: Float = 1.0f, // Cycles 1.0f -> 1.5f -> 2.0f
)

/**
 * Lightweight Android [MediaPlayer] voice note player supporting live 1.0x / 1.5x / 2.0x
 * speed switching via [PlaybackParams.setSpeed] with zero ExoPlayer/Media3 binary weight.
 *
 * Progress polling coroutine runs strictly while audio is playing so idle battery draw is zero.
 */
class VoicePlayerController(
    dispatchers: AppDispatchers,
) {
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.mainImmediate)
    private var mediaPlayer: MediaPlayer? = null
    private var tickerJob: Job? = null

    private val _state = MutableStateFlow(VoicePlaybackState())
    val state: StateFlow<VoicePlaybackState> = _state.asStateFlow()

    fun togglePlayPause(messageId: Long, localFilePath: String) {
        val current = _state.value
        val player = mediaPlayer

        if (current.activeMessageId == messageId && player != null) {
            if (player.isPlaying) {
                player.pause()
                stopTicker()
                _state.update { it.copy(isPlaying = false) }
            } else {
                applySpeed(player, current.playbackSpeed)
                player.start()
                _state.update { it.copy(isPlaying = true) }
                startTicker()
            }
            return
        }

        stopAndRelease()
        val chosenSpeed = current.playbackSpeed
        runCatching {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build(),
                )
                setDataSource(localFilePath)
                prepare()
                setOnCompletionListener {
                    stopTicker()
                    _state.update {
                        it.copy(isPlaying = false, progressFraction = 0f, elapsedSeconds = 0)
                    }
                }
            }
            mediaPlayer = mp
            applySpeed(mp, chosenSpeed)
            mp.start()
            _state.value = VoicePlaybackState(
                activeMessageId = messageId,
                isPlaying = true,
                progressFraction = 0f,
                elapsedSeconds = 0,
                playbackSpeed = chosenSpeed,
            )
            startTicker()
        }.onFailure {
            stopAndRelease()
        }
    }

    /**
     * Cycles voice playback speed: 1.0x -> 1.5x -> 2.0x -> 1.0x.
     */
    fun cycleSpeed() {
        val nextSpeed = when (_state.value.playbackSpeed) {
            1.0f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        _state.update { it.copy(playbackSpeed = nextSpeed) }
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            applySpeed(player, nextSpeed)
        }
    }

    fun stopAndRelease() {
        stopTicker()
        runCatching {
            mediaPlayer?.stop()
        }
        runCatching {
            mediaPlayer?.release()
        }
        mediaPlayer = null
        _state.update {
            it.copy(activeMessageId = null, isPlaying = false, progressFraction = 0f, elapsedSeconds = 0)
        }
    }

    private fun applySpeed(player: MediaPlayer, speed: Float) {
        runCatching {
            val params: PlaybackParams = player.playbackParams.setSpeed(speed)
            player.playbackParams = params
        }
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive) {
                val mp = mediaPlayer
                if (mp != null && mp.isPlaying) {
                    val dur = mp.duration.coerceAtLeast(1)
                    val pos = mp.currentPosition.coerceAtLeast(0)
                    _state.update {
                        it.copy(
                            progressFraction = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f),
                            elapsedSeconds = pos / 1000,
                        )
                    }
                }
                delay(33L)
            }
        }
    }

    private fun stopTicker() {
        tickerJob?.cancel()
        tickerJob = null
    }
}
