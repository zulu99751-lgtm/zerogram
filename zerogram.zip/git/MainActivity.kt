package app.zerogram

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.zerogram.core.designsystem.ZeroGramTheme
import app.zerogram.core.tdlib.model.AuthState
import app.zerogram.di.AppContainer
import app.zerogram.feature.auth.AuthRoute
import app.zerogram.feature.chat.ChatRoute
import app.zerogram.feature.chats.ChatsRoute

@Immutable
private data class ActiveChatTarget(
    val chatId: Long,
    val title: String,
)

private val ActiveChatSaver: Saver<ActiveChatTarget?, List<String>> = Saver(
    save = { target ->
        if (target == null) emptyList() else listOf(target.chatId.toString(), target.title)
    },
    restore = { saved ->
        if (saved.size < 2) null else ActiveChatTarget(saved[0].toLong(), saved[1])
    },
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.BLACK),
        )
        super.onCreate(savedInstanceState)
        requestPeakRefreshRate()

        val container = (application as ZeroGramApplication).container

        setContent {
            ZeroGramTheme {
                ZeroGramRoot(container = container)
            }
        }
    }

    private fun requestPeakRefreshRate() {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay
        } ?: return

        val currentMode = display.mode
        val peakMode = display.supportedModes
            .filter {
                it.physicalWidth == currentMode.physicalWidth &&
                    it.physicalHeight == currentMode.physicalHeight
            }
            .maxByOrNull { it.refreshRate }
            ?: return

        if (peakMode.modeId != currentMode.modeId) {
            window.attributes = window.attributes.apply {
                preferredDisplayModeId = peakMode.modeId
            }
        }
    }
}

/**
 * Zero-overhead Single-Activity root host.
 * Keeps [ChatsRoute] composed behind [ChatRoute] when a chat is opened so returning back
 * restores the exact 120 Hz dialog scroll offset in 0 ms without re-binding LazyColumn!
 */
@Composable
private fun ZeroGramRoot(
    container: AppContainer,
) {
    val authState by container.tdLibManager.authState.collectAsStateWithLifecycle()
    var openChat by rememberSaveable(stateSaver = ActiveChatSaver) { mutableStateOf(null) }

    if (authState !is AuthState.Ready) {
        openChat = null
        AuthRoute(tdLibManager = container.tdLibManager)
        return
    }

    BackHandler(enabled = openChat != null) {
        openChat = null
    }

    Box(modifier = Modifier.fillMaxSize()) {
        ChatsRoute(
            tdLibManager = container.tdLibManager,
            chatsRepository = container.chatsRepository,
            onOpenChat = { id, title ->
                openChat = ActiveChatTarget(chatId = id, title = title)
            },
        )

        val currentChat = openChat
        if (currentChat != null) {
            ChatRoute(
                chatId = currentChat.chatId,
                initialTitle = currentChat.title,
                chatMessagesRepository = container.chatMessagesRepository,
                voicePlayerController = container.voicePlayerController,
                onBack = { openChat = null },
            )
        }
    }
}
