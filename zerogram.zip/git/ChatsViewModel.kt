package app.zerogram.feature.chats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import app.zerogram.core.tdlib.ChatsRepository
import app.zerogram.core.tdlib.TdLibManager
import app.zerogram.core.tdlib.model.DialogSummary
import app.zerogram.core.tdlib.model.NetworkSyncState
import kotlinx.collections.immutable.toImmutableList
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ChatsViewModel(
    private val tdLibManager: TdLibManager,
    private val chatsRepository: ChatsRepository,
) : ViewModel() {

    private val selectedFolderId = MutableStateFlow<Int?>(null)

    private val activeDialogsFlow = selectedFolderId.flatMapLatest { folderId ->
        chatsRepository.observeDialogs(folderId)
    }

    val uiState: StateFlow<ChatsUiState> = combine(
        chatsRepository.folders,
        selectedFolderId,
        activeDialogsFlow,
        tdLibManager.networkState,
    ) { folders, currentFolderId, dialogs, netState ->
        val header = when (netState) {
            NetworkSyncState.WAITING_FOR_NETWORK -> "Ожидание сети…"
            NetworkSyncState.CONNECTING -> "Соединение…"
            NetworkSyncState.UPDATING -> "Обновление…"
            NetworkSyncState.READY -> "ZeroGram"
        }

        ChatsUiState(
            headerStatus = header,
            folders = folders.map { tab ->
                FolderTabUi(
                    folderId = tab.folderId,
                    title = tab.title,
                    unreadChatsCount = tab.unreadChatsCount,
                )
            }.toImmutableList(),
            selectedFolderId = currentFolderId,
            dialogs = dialogs.map(::mapDialogToUi).toImmutableList(),
            isSyncingInitialList = dialogs.isEmpty() && netState != NetworkSyncState.READY,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = ChatsUiState(),
    )

    fun onIntent(intent: ChatsIntent) {
        when (intent) {
            is ChatsIntent.SelectFolder -> {
                if (selectedFolderId.value == intent.folderId) return
                selectedFolderId.value = intent.folderId
                viewModelScope.launch {
                    chatsRepository.loadMoreChats(folderId = intent.folderId, limit = 40)
                }
            }
            ChatsIntent.ReachListTail -> {
                val folderId = selectedFolderId.value
                viewModelScope.launch {
                    chatsRepository.loadMoreChats(folderId = folderId, limit = 40)
                }
            }
            ChatsIntent.LogOut -> {
                viewModelScope.launch {
                    runCatching { tdLibManager.logOut() }
                }
            }
        }
    }

    private fun mapDialogToUi(item: DialogSummary): DialogRowUi = DialogRowUi(
        chatId = item.chatId,
        title = item.title,
        avatarInitials = item.avatarInitials,
        avatarColorArgb = item.avatarColorArgb,
        avatarLocalPath = item.avatarLocalPath,
        previewText = item.previewText,
        isDraft = item.isDraft,
        formattedTime = item.formattedTime,
        unreadCount = item.unreadCount,
        isPinned = item.isPinned,
        showOutgoingStatus = item.showOutgoingStatus,
        isOutgoingRead = item.isOutgoingRead,
    )

    companion object {
        fun factory(
            tdLibManager: TdLibManager,
            chatsRepository: ChatsRepository,
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return ChatsViewModel(tdLibManager, chatsRepository) as T
            }
        }
    }
}
