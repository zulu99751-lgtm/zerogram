package app.zerogram.core.tdlib

import androidx.paging.PagingSource
import androidx.paging.PagingState
import app.zerogram.core.tdlib.model.ChatMessageItem
import org.drinkless.tdlib.TdApi

/**
 * Step 3 Paging 3 Source over [TdApi.GetChatHistory].
 *
 * Handles TDLib's partial local return behavior: if the first call returns fewer than 8 items
 * because only the head message was cached in SQLite, immediately chains one follow-up fetch
 * from the oldest returned message ID so every scroll page is dense and jank-free.
 */
class ChatHistoryPagingSource(
    private val chatId: Long,
    private val tdLibManager: TdLibManager,
    private val messageMapper: suspend (TdApi.Message) -> ChatMessageItem,
    private val onTopSliceLoaded: (List<ChatMessageItem>) -> Unit,
) : PagingSource<Long, ChatMessageItem>() {

    override fun getRefreshKey(state: PagingState<Long, ChatMessageItem>): Long? = 0L

    override suspend fun load(params: LoadParams<Long>): LoadResult<Long, ChatMessageItem> {
        val fromMessageId = params.key ?: 0L
        val targetSize = params.loadSize.coerceIn(20, 60)

        return try {
            val rawMessages = ArrayList<TdApi.Message>(targetSize)
            val firstBatch = tdLibManager.send(
                TdApi.GetChatHistory(chatId, fromMessageId, 0, targetSize, false),
            )
            val firstArray = firstBatch.messages ?: emptyArray()
            for (msg in firstArray) {
                if (msg != null) rawMessages.add(msg)
            }

            // Second-hop fill when TDLib returns only the locally cached tail message on first pass
            if (rawMessages.isNotEmpty() && rawMessages.size < 8) {
                val tailId = rawMessages.last().id
                val secondBatch = tdLibManager.send(
                    TdApi.GetChatHistory(chatId, tailId, 0, targetSize - rawMessages.size, false),
                )
                val secondArray = secondBatch.messages ?: emptyArray()
                for (msg in secondArray) {
                    if (msg != null && rawMessages.none { it.id == msg.id }) {
                        rawMessages.add(msg)
                    }
                }
            }

            val mapped = ArrayList<ChatMessageItem>(rawMessages.size)
            for (msg in rawMessages) {
                mapped.add(messageMapper(msg))
            }

            if (fromMessageId == 0L && mapped.isNotEmpty()) {
                onTopSliceLoaded(mapped)
                // Mark visible head messages read asynchronously
                val unreadIds = rawMessages.take(15).map { it.id }.toLongArray()
                tdLibManager.sendFireAndForget(
                    TdApi.ViewMessages().apply {
                        this.chatId = this@ChatHistoryPagingSource.chatId
                        this.messageIds = unreadIds
                        this.forceRead = false
                    },
                )
            }

            val nextKey = if (rawMessages.isEmpty()) {
                null
            } else {
                rawMessages.last().id
            }

            LoadResult.Page(
                data = mapped,
                prevKey = null, // reverseLayout = true scrolls older messages via nextKey
                nextKey = nextKey,
            )
        } catch (t: Throwable) {
            LoadResult.Error(t)
        }
    }
}
