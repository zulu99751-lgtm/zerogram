package app.zerogram.feature.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.paging.compose.LazyPagingItems
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.paging.compose.itemContentType
import androidx.paging.compose.itemKey
import app.zerogram.core.common.FastFormatters
import app.zerogram.core.designsystem.LocalZeroGramColors
import app.zerogram.core.designsystem.rememberLocalImageBitmap
import app.zerogram.core.tdlib.ChatMessagesRepository

@Composable
fun ChatRoute(
    chatId: Long,
    initialTitle: String,
    chatMessagesRepository: ChatMessagesRepository,
    voicePlayerController: VoicePlayerController,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val viewModel: ChatViewModel = viewModel(
        key = "chat_$chatId",
        factory = ChatViewModel.factory(
            chatId = chatId,
            initialTitle = initialTitle,
            chatMessagesRepository = chatMessagesRepository,
            voicePlayerController = voicePlayerController,
        ),
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val pagedItems = viewModel.pagedMessages.collectAsLazyPagingItems()

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            viewModel.onIntent(ChatIntent.SendPickedPhoto(uri))
        }
    }

    ChatContent(
        state = state,
        pagedItems = pagedItems,
        onIntent = viewModel::onIntent,
        onLaunchPhotoPicker = {
            photoPicker.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
            )
        },
        onBack = onBack,
        modifier = modifier,
    )
}

@Composable
fun ChatContent(
    state: ChatUiState,
    pagedItems: LazyPagingItems<MessageBubbleUi>,
    onIntent: (ChatIntent) -> Unit,
    onLaunchPhotoPicker: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalZeroGramColors.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.backgroundAmoled)
            .imePadding(),
    ) {
        // Minimal Chat Top Bar + global active voice speed toggle pill when voice is playing
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.surfaceTopBar)
                .statusBarsPadding()
                .height(52.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) {
                Text(
                    text = "← Назад",
                    color = colors.accentPrimary,
                    fontSize = 15.sp,
                )
            }
            Text(
                text = state.title,
                color = colors.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp),
            )
            if (state.voicePlayback.activeMessageId != null) {
                SpeedChip(
                    speed = state.voicePlayback.playbackSpeed,
                    onClick = { onIntent(ChatIntent.CycleVoiceSpeed) },
                )
            }
        }

        // Instant Open: display pre-warmed hot cache on Frame 1 until Paging 3 commits items
        val hasPagedData = pagedItems.itemCount > 0
        LazyColumn(
            reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            if (hasPagedData) {
                items(
                    count = pagedItems.itemCount,
                    key = pagedItems.itemKey { it.id },
                    contentType = pagedItems.itemContentType { it.media::class.simpleName },
                ) { index ->
                    val bubble = pagedItems[index] ?: return@items
                    LightweightMessageBubble(
                        bubble = bubble,
                        voicePlayback = state.voicePlayback,
                        isStickerAnimated = state.tappedStickerIds.contains(bubble.id),
                        onIntent = onIntent,
                    )
                }
            } else {
                items(
                    items = state.instantSeedMessages,
                    key = { it.id },
                    contentType = { it.media::class.simpleName },
                ) { bubble ->
                    LightweightMessageBubble(
                        bubble = bubble,
                        voicePlayback = state.voicePlayback,
                        isStickerAnimated = state.tappedStickerIds.contains(bubble.id),
                        onIntent = onIntent,
                    )
                }
            }
        }

        // Lightweight Composer Bar (Photo Picker + Text Input + Send)
        ComposerBar(
            text = state.inputText,
            onTextChanged = { onIntent(ChatIntent.InputChanged(it)) },
            onPickPhoto = onLaunchPhotoPicker,
            onSendText = { onIntent(ChatIntent.SendText) },
        )
    }
}

/**
 * Custom lightweight bubble with minimal container nesting:
 * Background rounded rect is rendered directly via [drawBehind] without Card/Surface elevation layers.
 */
@Composable
private fun LightweightMessageBubble(
    bubble: MessageBubbleUi,
    voicePlayback: VoicePlaybackState,
    isStickerAnimated: Boolean,
    onIntent: (ChatIntent) -> Unit,
) {
    val colors = LocalZeroGramColors.current
    val alignment = if (bubble.isOutgoing) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleFill = if (bubble.isOutgoing) colors.bubbleOutgoing else colors.bubbleIncoming

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = alignment,
    ) {
        if (bubble.media is BubbleMediaUi.Sticker) {
            StickerBubbleBody(
                messageId = bubble.id,
                sticker = bubble.media,
                isAnimated = isStickerAnimated,
                formattedTime = bubble.formattedTime + bubble.statusBadge,
                onIntent = onIntent,
            )
        } else {
            Column(
                modifier = Modifier
                    .widthIn(min = 84.dp, max = 304.dp)
                    .drawBehind {
                        drawRoundRect(
                            color = bubbleFill,
                            cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                        )
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                if (!bubble.isOutgoing && !bubble.senderName.isNullOrBlank()) {
                    Text(
                        text = bubble.senderName,
                        color = colors.accentPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                when (val media = bubble.media) {
                    is BubbleMediaUi.Text -> {
                        Text(
                            text = media.text,
                            color = colors.textPrimary,
                            fontSize = 15.sp,
                            lineHeight = 20.sp,
                        )
                    }
                    is BubbleMediaUi.Photo -> {
                        PhotoBubbleBody(media = media, onIntent = onIntent)
                    }
                    is BubbleMediaUi.Voice -> {
                        VoiceBubbleBody(
                            messageId = bubble.id,
                            voice = media,
                            voicePlayback = voicePlayback,
                            onIntent = onIntent,
                        )
                    }
                    is BubbleMediaUi.DocumentFile -> {
                        DocumentBubbleBody(doc = media, onIntent = onIntent)
                    }
                    is BubbleMediaUi.VideoNoteTappedOnly -> {
                        Text(
                            text = "🎥 Видеокружок (${media.durationLabel}) · автозапуск отключен",
                            color = colors.textSecondary,
                            fontSize = 13.sp,
                        )
                    }
                    is BubbleMediaUi.Sticker -> Unit
                }

                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = bubble.formattedTime + bubble.statusBadge,
                    color = colors.textSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.End),
                )
            }
        }
    }
}

@Composable
private fun PhotoBubbleBody(
    media: BubbleMediaUi.Photo,
    onIntent: (ChatIntent) -> Unit,
) {
    val colors = LocalZeroGramColors.current
    val bmp by rememberLocalImageBitmap(
        localPath = media.localPath,
        targetMaxPx = 720,
        preferOpaqueRgb565 = true,
    )

    Column {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(media.aspectRatio)
                .clip(RoundedCornerShape(10.dp))
                .background(colors.surfaceCard)
                .clickable { onIntent(ChatIntent.ClickPhoto(media.fileId, media.localPath)) },
            contentAlignment = Alignment.Center,
        ) {
            val image = bmp
            if (image != null) {
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    text = if (media.isDownloading) "Загрузка фото…" else "Нажмите для загрузки фото",
                    color = colors.textSecondary,
                    fontSize = 12.sp,
                )
            }
        }
        if (media.caption.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = media.caption,
                color = colors.textPrimary,
                fontSize = 14.sp,
            )
        }
    }
}

/**
 * Voice note bubble with single-Canvas waveform rendering and inline 1x / 1.5x / 2x speed button.
 */
@Composable
private fun VoiceBubbleBody(
    messageId: Long,
    voice: BubbleMediaUi.Voice,
    voicePlayback: VoicePlaybackState,
    onIntent: (ChatIntent) -> Unit,
) {
    val colors = LocalZeroGramColors.current
    val isThisActive = voicePlayback.activeMessageId == messageId
    val isPlaying = isThisActive && voicePlayback.isPlaying
    val progress = if (isThisActive) voicePlayback.progressFraction else 0f

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        // Play / Pause / Download circle button
        Box(
            modifier = Modifier
                .size(38.dp)
                .drawBehind {
                    drawCircle(color = colors.accentPrimary)
                }
                .clickable {
                    onIntent(ChatIntent.ClickVoice(messageId, voice.fileId, voice.localPath))
                },
            contentAlignment = Alignment.Center,
        ) {
            val iconLabel = when {
                voice.localPath.isNullOrBlank() -> if (voice.isDownloading) "…" else "↓"
                isPlaying -> "❚❚"
                else -> "▶"
            }
            Text(
                text = iconLabel,
                color = colors.backgroundAmoled,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp),
            ) {
                val samples = voice.waveformSamples
                val count = samples.size.coerceAtLeast(1)
                val stepX = size.width / count
                val barWidth = (stepX * 0.58f).coerceAtLeast(2f)

                for (i in 0 until count) {
                    val ratio = i.toFloat() / count.toFloat()
                    val amp = samples[i]
                    val barHeight = (size.height * amp).coerceAtLeast(3.dp.toPx())
                    val topY = (size.height - barHeight) / 2f
                    drawRoundRect(
                        color = if (ratio <= progress) colors.accentPrimary else colors.textSecondary,
                        topLeft = Offset(i * stepX, topY),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))
            val timeText = if (isThisActive) {
                "${FastFormatters.formatDurationSeconds(voicePlayback.elapsedSeconds)} / ${voice.durationLabel}"
            } else {
                voice.durationLabel
            }
            Text(
                text = timeText,
                color = colors.textSecondary,
                fontSize = 11.sp,
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        SpeedChip(
            speed = voicePlayback.playbackSpeed,
            onClick = { onIntent(ChatIntent.CycleVoiceSpeed) },
        )
    }
}

@Composable
private fun SpeedChip(
    speed: Float,
    onClick: () -> Unit,
) {
    val colors = LocalZeroGramColors.current
    val label = when (speed) {
        1.5f -> "1.5x"
        2.0f -> "2x"
        else -> "1x"
    }
    Text(
        text = label,
        color = colors.accentPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .drawBehind {
                drawRoundRect(
                    color = colors.accentMuted,
                    cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()),
                )
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

/**
 * Static WebP sticker renderer: renders static frame with ARGB_8888 transparency;
 * animated TGS/WebM stickers never auto-run and only load/activate on explicit tap.
 */
@Composable
private fun StickerBubbleBody(
    messageId: Long,
    sticker: BubbleMediaUi.Sticker,
    isAnimated: Boolean,
    formattedTime: String,
    onIntent: (ChatIntent) -> Unit,
) {
    val colors = LocalZeroGramColors.current
    val bmp by rememberLocalImageBitmap(
        localPath = sticker.staticPreviewLocalPath,
        targetMaxPx = 384,
        preferOpaqueRgb565 = false,
    )

    Column(
        horizontalAlignment = Alignment.End,
        modifier = Modifier.clickable {
            onIntent(
                ChatIntent.ClickSticker(
                    messageId = messageId,
                    stickerFileId = sticker.stickerFileId,
                    isAnimatedFormat = sticker.isAnimatedFormat,
                ),
            )
        },
    ) {
        Box(
            modifier = Modifier.size(148.dp),
            contentAlignment = Alignment.Center,
        ) {
            val image = bmp
            if (image != null) {
                Image(
                    bitmap = image,
                    contentDescription = sticker.emoji,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    text = sticker.emoji.ifBlank { "✨" },
                    fontSize = 44.sp,
                )
            }

            if (sticker.isAnimatedFormat && !isAnimated) {
                Text(
                    text = "TAP",
                    color = colors.textPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .drawBehind {
                            drawRoundRect(
                                color = colors.surfaceCard,
                                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                            )
                        }
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                )
            }
        }
        Text(
            text = formattedTime,
            color = colors.textSecondary,
            fontSize = 11.sp,
        )
    }
}

@Composable
private fun DocumentBubbleBody(
    doc: BubbleMediaUi.DocumentFile,
    onIntent: (ChatIntent) -> Unit,
) {
    val colors = LocalZeroGramColors.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onIntent(ChatIntent.ClickDocument(doc.fileId, doc.localPath)) },
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .drawBehind { drawCircle(color = colors.accentMuted) },
            contentAlignment = Alignment.Center,
        ) {
            val stateGlyph = when {
                !doc.localPath.isNullOrBlank() -> "✓"
                doc.isDownloading -> "…"
                else -> "↓"
            }
            Text(
                text = stateGlyph,
                color = colors.accentPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = doc.fileName,
                color = colors.textPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = doc.sizeLabel,
                color = colors.textSecondary,
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun ComposerBar(
    text: String,
    onTextChanged: (String) -> Unit,
    onPickPhoto: () -> Unit,
    onSendText: () -> Unit,
) {
    val colors = LocalZeroGramColors.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surfaceTopBar)
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Photo attachment trigger (Android Photo Picker)
        TextButton(onClick = onPickPhoto) {
            Text(
                text = "Фото",
                color = colors.accentPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .drawBehind {
                    drawRoundRect(
                        color = colors.surfaceInput,
                        cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                    )
                }
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            if (text.isEmpty()) {
                Text(
                    text = "Сообщение…",
                    color = colors.textSecondary,
                    fontSize = 15.sp,
                )
            }
            BasicTextField(
                value = text,
                onValueChange = onTextChanged,
                textStyle = TextStyle(
                    color = colors.textPrimary,
                    fontSize = 15.sp,
                ),
                cursorBrush = SolidColor(colors.accentPrimary),
                maxLines = 5,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        TextButton(
            onClick = onSendText,
            enabled = text.isNotBlank(),
        ) {
            Text(
                text = "Отпр.",
                color = if (text.isNotBlank()) colors.accentPrimary else colors.textSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}
