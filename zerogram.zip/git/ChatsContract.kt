package app.zerogram.feature.chats

import androidx.compose.runtime.Immutable
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf

@Immutable
data class FolderTabUi(
    val folderId: Int?, // null == Main chat list ("Все чаты")
    val title: String,
    val unreadChatsCount: Int,
)

@Immutable
data class DialogRowUi(
    val chatId: Long,
    val title: String,
    val avatarInitials: String,
    val avatarColorArgb: Int,
    val avatarLocalPath: String?,
    val previewText: String,
    val isDraft: Boolean,
    val formattedTime: String,
    val unreadCount: Int,
    val isPinned: Boolean,
    val showOutgoingStatus: Boolean,
    val isOutgoingRead: Boolean,
)

@Immutable
data class ChatsUiState(
    val headerStatus: String = "ZeroGram",
    val folders: ImmutableList<FolderTabUi> = persistentListOf(
        FolderTabUi(folderId = null, title = "Все чаты", unreadChatsCount = 0),
    ),
    val selectedFolderId: Int? = null,
    val dialogs: ImmutableList<DialogRowUi> = persistentListOf(),
    val isSyncingInitialList: Boolean = true,
)

sealed interface ChatsIntent {
    data class SelectFolder(val folderId: Int?) : ChatsIntent
    data object ReachListTail : ChatsIntent
    data object LogOut : ChatsIntent
}
