package app.zerogram.core.designsystem

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Zero-bloat in-memory LruCache + RGB_565 / ARGB_8888 sub-sampled decoder for local TDLib files
 * (chat avatars, message photos, and static WebP sticker previews) without heavy third-party image loaders.
 */
object LocalBitmapCache {
    private val maxMemoryKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
    private val cacheSizeKb = (maxMemoryKb / 8).coerceAtLeast(4 * 1024)

    private val memoryCache = object : LruCache<String, ImageBitmap>(cacheSizeKb) {
        override fun sizeOf(key: String, value: ImageBitmap): Int {
            return (value.width * value.height * 4) / 1024
        }
    }

    fun getCached(key: String): ImageBitmap? = memoryCache.get(key)

    suspend fun loadDownsampled(
        localPath: String,
        targetMaxPx: Int,
        preferOpaqueRgb565: Boolean,
    ): ImageBitmap? {
        val cacheKey = "$localPath@$targetMaxPx"
        memoryCache.get(cacheKey)?.let { return it }

        return withContext(Dispatchers.IO) {
            memoryCache.get(cacheKey)?.let { return@withContext it }
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(localPath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

                var sampleSize = 1
                while (
                    bounds.outWidth / (sampleSize * 2) >= targetMaxPx &&
                    bounds.outHeight / (sampleSize * 2) >= targetMaxPx
                ) {
                    sampleSize *= 2
                }

                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = if (preferOpaqueRgb565) {
                        Bitmap.Config.RGB_565
                    } else {
                        Bitmap.Config.ARGB_8888
                    }
                }
                val bmp = BitmapFactory.decodeFile(localPath, decodeOpts)?.asImageBitmap()
                if (bmp != null) {
                    memoryCache.put(cacheKey, bmp)
                }
                bmp
            }.getOrNull()
        }
    }
}

@Composable
fun rememberLocalImageBitmap(
    localPath: String?,
    targetMaxPx: Int,
    preferOpaqueRgb565: Boolean = true,
): State<ImageBitmap?> {
    val initial = if (!localPath.isNullOrBlank()) {
        LocalBitmapCache.getCached("$localPath@$targetMaxPx")
    } else {
        null
    }
    return produceState(initialValue = initial, key1 = localPath, key2 = targetMaxPx) {
        if (localPath.isNullOrBlank()) {
            value = null
            return@produceState
        }
        if (value == null) {
            value = LocalBitmapCache.loadDownsampled(
                localPath = localPath,
                targetMaxPx = targetMaxPx,
                preferOpaqueRgb565 = preferOpaqueRgb565,
            )
        }
    }
}
