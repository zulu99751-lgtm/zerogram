package org.drinkless.tdlib;

/**
 * Official TDLib Java JNI entrypoint contract (matches tdlib/td org.drinkless.tdlib.Client).
 */
public final class Client {
    static {
        try {
            System.loadLibrary("tdjni");
        } catch (UnsatisfiedLinkError ignored) {
            // Checked in TdLibManager.ensureNativeLibraryLoaded()
        }
    }

    public interface ResultHandler {
        void onResult(TdApi.Object object);
    }

    public interface ExceptionHandler {
        void onException(Throwable e);
    }

    public static final class ExecutionException extends Exception {
        public final TdApi.Error error;

        public ExecutionException(TdApi.Error error) {
            super(error.code + ": " + error.message);
            this.error = error;
        }
    }

    private final int nativeClientId;

    private Client(
            ResultHandler updateHandler,
            ExceptionHandler updateExceptionHandler,
            ExceptionHandler defaultExceptionHandler
    ) {
        this.nativeClientId = createNativeClient();
    }

    public static Client create(
            ResultHandler updateHandler,
            ExceptionHandler updateExceptionHandler,
            ExceptionHandler defaultExceptionHandler
    ) {
        return new Client(updateHandler, updateExceptionHandler, defaultExceptionHandler);
    }

    public <T extends TdApi.Object> void send(
            TdApi.Function<T> query,
            ResultHandler resultHandler,
            ExceptionHandler exceptionHandler
    ) {
        nativeClientSend(nativeClientId, query, resultHandler, exceptionHandler);
    }

    public <T extends TdApi.Object> void send(
            TdApi.Function<T> query,
            ResultHandler resultHandler
    ) {
        send(query, resultHandler, null);
    }

    @SuppressWarnings("unchecked")
    public static <T extends TdApi.Object> T execute(TdApi.Function<T> query) throws ExecutionException {
        TdApi.Object result = nativeClientExecute(query);
        if (result instanceof TdApi.Error) {
            throw new ExecutionException((TdApi.Error) result);
        }
        return (T) result;
    }

    private static native int createNativeClient();
    private static native void nativeClientSend(
            int nativeClientId,
            TdApi.Function<?> query,
            ResultHandler resultHandler,
            ExceptionHandler exceptionHandler
    );
    private static native TdApi.Object nativeClientExecute(TdApi.Function<?> query);
}
