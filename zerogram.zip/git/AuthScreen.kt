package app.zerogram.feature.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.zerogram.core.designsystem.LocalZeroGramColors
import app.zerogram.core.tdlib.TdLibManager
import app.zerogram.core.tdlib.model.CodeDeliveryChannel

@Composable
fun AuthRoute(
    tdLibManager: TdLibManager,
    modifier: Modifier = Modifier,
) {
    val viewModel: AuthViewModel = viewModel(
        factory = AuthViewModel.factory(tdLibManager),
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    AuthContent(
        state = state,
        onIntent = viewModel::onIntent,
        modifier = modifier,
    )
}

@Composable
fun AuthContent(
    state: AuthUiState,
    onIntent: (AuthIntent) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalZeroGramColors.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.backgroundAmoled)
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start,
    ) {
        Text(
            text = "ZeroGram",
            color = colors.textPrimary,
            fontSize = 28.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(6.dp))

        when (state.step) {
            AuthStep.INITIALIZING -> {
                Text(
                    text = "Инициализация движка TDLib…",
                    color = colors.textSecondary,
                    fontSize = 15.sp,
                )
                Spacer(modifier = Modifier.height(20.dp))
                CircularProgressIndicator(
                    color = colors.accentPrimary,
                    strokeWidth = 2.dp,
                )
            }

            AuthStep.API_CREDENTIALS_INPUT -> {
                Text(
                    text = state.setupDiagnosticMessage.orEmpty(),
                    color = colors.textSecondary,
                    fontSize = 14.sp,
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = state.apiIdInput,
                    onValueChange = { onIntent(AuthIntent.ApiIdChanged(it)) },
                    label = { Text("Telegram API ID") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = state.apiHashInput,
                    onValueChange = { onIntent(AuthIntent.ApiHashChanged(it)) },
                    label = { Text("Telegram API Hash") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Ascii,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onIntent(AuthIntent.SaveApiCredentials) },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )

                ErrorBanner(state.errorMessage)
                Spacer(modifier = Modifier.height(16.dp))

                PrimaryActionButton(
                    text = "Сохранить и запустить движок",
                    enabled = !state.isLoading,
                    onClick = { onIntent(AuthIntent.SaveApiCredentials) },
                )
            }

            AuthStep.SETUP_REQUIRED -> {
                Text(
                    text = state.setupDiagnosticMessage.orEmpty(),
                    color = colors.danger,
                    fontSize = 14.sp,
                )
            }

            AuthStep.PHONE_NUMBER -> {
                Text(
                    text = "Введите номер телефона Telegram",
                    color = colors.textSecondary,
                    fontSize = 15.sp,
                )
                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = state.phoneInput,
                    onValueChange = { onIntent(AuthIntent.PhoneChanged(it)) },
                    label = { Text("Номер телефона") },
                    singleLine = true,
                    enabled = !state.isLoading,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onIntent(AuthIntent.SubmitPhone) },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )

                ErrorBanner(state.errorMessage)
                Spacer(modifier = Modifier.height(16.dp))

                PrimaryActionButton(
                    text = if (state.isLoading) "Отправка…" else "Продолжить",
                    enabled = !state.isLoading,
                    onClick = { onIntent(AuthIntent.SubmitPhone) },
                )
            }

            AuthStep.VERIFICATION_CODE -> {
                val channelHint = when (state.deliveryChannel) {
                    CodeDeliveryChannel.TELEGRAM_APP -> "Код отправлен в активное приложение Telegram"
                    CodeDeliveryChannel.SMS -> "Код отправлен по SMS на ${state.phoneInput}"
                    CodeDeliveryChannel.PHONE_CALL -> "Продиктуем код в звонке"
                    else -> "Введите код для ${state.phoneInput}"
                }
                Text(
                    text = channelHint,
                    color = colors.textSecondary,
                    fontSize = 15.sp,
                )
                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = state.codeInput,
                    onValueChange = { onIntent(AuthIntent.CodeChanged(it)) },
                    label = { Text("Код (${state.expectedCodeLength} цифр)") },
                    singleLine = true,
                    enabled = !state.isLoading,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onIntent(AuthIntent.SubmitCode) },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )

                ErrorBanner(state.errorMessage)
                Spacer(modifier = Modifier.height(16.dp))

                PrimaryActionButton(
                    text = if (state.isLoading) "Проверка…" else "Подтвердить",
                    enabled = !state.isLoading && state.codeInput.isNotBlank(),
                    onClick = { onIntent(AuthIntent.SubmitCode) },
                )
                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = { onIntent(AuthIntent.ResendCode) },
                    enabled = !state.isLoading,
                ) {
                    Text(
                        text = "Отправить код повторно",
                        color = colors.accentPrimary,
                    )
                }
            }

            AuthStep.TWO_FACTOR_PASSWORD -> {
                val hintLine = if (state.passwordHint.isNotBlank()) {
                    "Облачный пароль 2FA (подсказка: ${state.passwordHint})"
                } else {
                    "Введите облачный пароль двухфакторной защиты"
                }
                Text(
                    text = hintLine,
                    color = colors.textSecondary,
                    fontSize = 15.sp,
                )
                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = state.passwordInput,
                    onValueChange = { onIntent(AuthIntent.PasswordChanged(it)) },
                    label = { Text("Пароль 2FA") },
                    singleLine = true,
                    enabled = !state.isLoading,
                    visualTransformation = if (state.isPasswordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        TextButton(onClick = { onIntent(AuthIntent.TogglePasswordVisibility) }) {
                            Text(
                                text = if (state.isPasswordVisible) "Скрыть" else "Показать",
                                color = colors.accentPrimary,
                                fontSize = 12.sp,
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onIntent(AuthIntent.SubmitPassword) },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )

                ErrorBanner(state.errorMessage)
                Spacer(modifier = Modifier.height(16.dp))

                PrimaryActionButton(
                    text = if (state.isLoading) "Вход…" else "Войти",
                    enabled = !state.isLoading && state.passwordInput.isNotEmpty(),
                    onClick = { onIntent(AuthIntent.SubmitPassword) },
                )
            }
        }
    }
}

@Composable
private fun ErrorBanner(errorMessage: String?) {
    if (errorMessage.isNullOrBlank()) return
    val colors = LocalZeroGramColors.current
    Spacer(modifier = Modifier.height(10.dp))
    Text(text = errorMessage, color = colors.danger, fontSize = 13.sp)
}

@Composable
private fun PrimaryActionButton(
    text: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val colors = LocalZeroGramColors.current
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = colors.accentPrimary,
            contentColor = colors.backgroundAmoled,
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
    ) {
        Text(text = text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
