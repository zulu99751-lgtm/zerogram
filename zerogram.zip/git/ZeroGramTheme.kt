package app.zerogram.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Pure AMOLED Dark tokens (#000000 turns off OLED subpixels for maximum battery savings).
 */
@Immutable
data class ZeroGramColors(
    val backgroundAmoled: Color = Color(0xFF000000),
    val surfaceTopBar: Color = Color(0xFF07080A),
    val surfaceCard: Color = Color(0xFF0E1014),
    val surfaceInput: Color = Color(0xFF14171D),
    val bubbleOutgoing: Color = Color(0xFF132C42),
    val bubbleIncoming: Color = Color(0xFF12151B),
    val accentPrimary: Color = Color(0xFF2AABEE),
    val accentMuted: Color = Color(0xFF1A3A4E),
    val textPrimary: Color = Color(0xFFF2F4F8),
    val textSecondary: Color = Color(0xFF8A919E),
    val dividerHairline: Color = Color(0xFF171A21),
    val unreadBadge: Color = Color(0xFF2AABEE),
    val danger: Color = Color(0xFFFF5252),
)

val LocalZeroGramColors = staticCompositionLocalOf { ZeroGramColors() }

private val AmoledMaterialScheme = darkColorScheme(
    primary = Color(0xFF2AABEE),
    onPrimary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF2F4F8),
    surface = Color(0xFF000000),
    surfaceContainer = Color(0xFF0E1014),
    onSurface = Color(0xFFF2F4F8),
    onSurfaceVariant = Color(0xFF8A919E),
    error = Color(0xFFFF5252),
)

@Composable
fun ZeroGramTheme(
    content: @Composable () -> Unit,
) {
    val colors = ZeroGramColors()
    CompositionLocalProvider(LocalZeroGramColors provides colors) {
        MaterialTheme(
            colorScheme = AmoledMaterialScheme,
            content = content,
        )
    }
}
