package app.zerogram.core.tdlib

import app.zerogram.core.common.AppDispatchers
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

data class LocalFileSnapshot(
    val fileId: Int,
    val localPath: String?,
    val isDownloading: Boolean,
)

/**
 * Tracks downloaded local file paths from [TdApi.UpdateFile] in lock-free memory
 * and schedules prioritized downloads without auto-downloading heavy media.
 */
class MediaFileStore(
    private val tdLibManager: TdLibManager,
    dispatchers: AppDispatchers,
) {
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.tdlibActor)
    private val snapshots = ConcurrentHashMap<Int, LocalFileSnapshot>(256)

    private val _fileUpdates = MutableSharedFlow<LocalFileSnapshot>(extraBufferCapacity = 128)
    val fileUpdates: SharedFlow<LocalFileSnapshot> = _fileUpdates.asSharedFlow()

    init {
        scope.launch {
            tdLibManager.updates.collect { update ->
                if (update is TdApi.UpdateFile) {
                    val f = update.file ?: return@collect
                    val snap = recordFile(f)
                    _fileUpdates.tryEmit(snap)
                }
            }
        }
    }

    fun recordFile(file: TdApi.File?): LocalFileSnapshot {
        if (file == null || file.id == 0) {
            return LocalFileSnapshot(0, null, false)
        }
        val local = file.local
        val path = if (local != null && local.isDownloadingCompleted && !local.path.isNullOrBlank()) {
            local.path
        } else {
            null
        }
        val snap = LocalFileSnapshot(
            fileId = file.id,
            localPath = path,
            isDownloading = local?.isDownloadingActive == true,
        )
        snapshots[file.id] = snap
        return snap
    }

    fun getLocalPath(fileId: Int?): String? {
        if (fileId == null || fileId == 0) return null
        return snapshots[fileId]?.localPath
    }

    fun isDownloading(fileId: Int?): Boolean {
        if (fileId == null || fileId == 0) return false
        return snapshots[fileId]?.isDownloading == true
    }

    /**
     * Triggers an async TDLib download (priority 1..32).
     * Used strictly for small avatars, static WebP previews, or explicit user taps.
     */
    fun ensureDownloaded(fileId: Int, priority: Int = 16) {
        if (fileId <= 0) return
        val existing = snapshots[fileId]
        if (existing?.localPath != null || existing?.isDownloading == true) return
        tdLibManager.sendFireAndForget(
            TdApi.DownloadFile(fileId, priority.coerceIn(1, 32), 0L, 0L, false),
        )
    }
}
