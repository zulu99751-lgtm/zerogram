package org.drinkless.tdlib;

/**
 * Compile-time TDLib 1.8+ Java schema contract covering Auth (Step 1),
 * Folders & Dialogs (Step 2), and Paging Chat History / Photos / Static WebP / Voice (Step 3).
 * Drop full generated TdApi.java from your TDLib build in place of this file when bundling libtdjni.so.
 */
public final class TdApi {
    private TdApi() {}

    public abstract static class Object {
        public abstract int getConstructor();
    }

    public abstract static class Function<R extends Object> extends Object {}

    public static class Ok extends Object {
        public static final int CONSTRUCTOR = -722616727;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class Error extends Object {
        public static final int CONSTRUCTOR = -1679978726;
        public int code;
        public String message;
        public Error() {}
        public Error(int code, String message) { this.code = code; this.message = message; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    // --- Logging & Engine Options ---
    public abstract static class LogStream extends Object {}
    public static class LogStreamEmpty extends LogStream {
        public static final int CONSTRUCTOR = -509930740;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class SetLogVerbosityLevel extends Function<Ok> {
        public static final int CONSTRUCTOR = -1107909468;
        public int newVerbosityLevel;
        public SetLogVerbosityLevel() {}
        public SetLogVerbosityLevel(int newVerbosityLevel) { this.newVerbosityLevel = newVerbosityLevel; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class SetLogStream extends Function<Ok> {
        public static final int CONSTRUCTOR = -1193884356;
        public LogStream logStream;
        public SetLogStream() {}
        public SetLogStream(LogStream logStream) { this.logStream = logStream; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public abstract static class OptionValue extends Object {}
    public static class OptionValueBoolean extends OptionValue {
        public static final int CONSTRUCTOR = -1028024189;
        public boolean value;
        public OptionValueBoolean() {}
        public OptionValueBoolean(boolean value) { this.value = value; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class OptionValueInteger extends OptionValue {
        public static final int CONSTRUCTOR = -1249723625;
        public long value;
        public OptionValueInteger() {}
        public OptionValueInteger(long value) { this.value = value; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class SetOption extends Function<Ok> {
        public static final int CONSTRUCTOR = 1493024240;
        public String name;
        public OptionValue value;
        public SetOption() {}
        public SetOption(String name, OptionValue value) { this.name = name; this.value = value; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    // --- Authorization (Step 1) ---
    public abstract static class AuthorizationState extends Object {}
    public static class AuthorizationStateWaitTdlibParameters extends AuthorizationState {
        public static final int CONSTRUCTOR = 904720988;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateWaitPhoneNumber extends AuthorizationState {
        public static final int CONSTRUCTOR = 306402531;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public abstract static class AuthenticationCodeType extends Object {}
    public static class AuthenticationCodeTypeTelegramMessage extends AuthenticationCodeType {
        public static final int CONSTRUCTOR = 621350221;
        public int length;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthenticationCodeTypeSms extends AuthenticationCodeType {
        public static final int CONSTRUCTOR = -1970706982;
        public int length;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthenticationCodeTypeCall extends AuthenticationCodeType {
        public static final int CONSTRUCTOR = 1948905666;
        public int length;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthenticationCodeTypeFlashCall extends AuthenticationCodeType {
        public static final int CONSTRUCTOR = -640814154;
        public String pattern;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthenticationCodeTypeMissedCall extends AuthenticationCodeType {
        public static final int CONSTRUCTOR = -336100516;
        public String phoneNumberPrefix;
        public int length;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthenticationCodeInfo extends Object {
        public static final int CONSTRUCTOR = -1229947002;
        public String phoneNumber;
        public AuthenticationCodeType type;
        public AuthenticationCodeType nextType;
        public int timeout;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateWaitCode extends AuthorizationState {
        public static final int CONSTRUCTOR = 52643073;
        public AuthenticationCodeInfo codeInfo;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateWaitPassword extends AuthorizationState {
        public static final int CONSTRUCTOR = 199335037;
        public String passwordHint;
        public boolean hasRecoveryEmailAddress;
        public boolean hasPassportData;
        public String recoveryEmailAddressPattern;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateReady extends AuthorizationState {
        public static final int CONSTRUCTOR = -1834871737;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateLoggingOut extends AuthorizationState {
        public static final int CONSTRUCTOR = 154449270;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateClosing extends AuthorizationState {
        public static final int CONSTRUCTOR = 445856911;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class AuthorizationStateClosed extends AuthorizationState {
        public static final int CONSTRUCTOR = 1526047584;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class SetTdlibParameters extends Function<Ok> {
        public static final int CONSTRUCTOR = -1623080115;
        public boolean useTestDc;
        public String databaseDirectory;
        public String filesDirectory;
        public byte[] databaseEncryptionKey;
        public boolean useFileDatabase;
        public boolean useChatInfoDatabase;
        public boolean useMessageDatabase;
        public boolean useSecretChats;
        public int apiId;
        public String apiHash;
        public String systemLanguageCode;
        public String deviceModel;
        public String systemVersion;
        public String applicationVersion;
        public SetTdlibParameters() {}
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class PhoneNumberAuthenticationSettings extends Object {
        public static final int CONSTRUCTOR = -1206127711;
        public boolean allowFlashCall;
        public boolean allowMissedCall;
        public boolean isCurrentPhoneNumber;
        public boolean hasUnknownPhoneNumber;
        public boolean allowSmsRetrieverApi;
        public String[] authenticationTokens;
        public PhoneNumberAuthenticationSettings() {}
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class SetAuthenticationPhoneNumber extends Function<Ok> {
        public static final int CONSTRUCTOR = -719163010;
        public String phoneNumber;
        public PhoneNumberAuthenticationSettings settings;
        public SetAuthenticationPhoneNumber() {}
        public SetAuthenticationPhoneNumber(String phoneNumber, PhoneNumberAuthenticationSettings settings) {
            this.phoneNumber = phoneNumber;
            this.settings = settings;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class CheckAuthenticationCode extends Function<Ok> {
        public static final int CONSTRUCTOR = 1126045588;
        public String code;
        public CheckAuthenticationCode() {}
        public CheckAuthenticationCode(String code) { this.code = code; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ResendAuthenticationCode extends Function<Ok> {
        public static final int CONSTRUCTOR = 885156145;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class CheckAuthenticationPassword extends Function<Ok> {
        public static final int CONSTRUCTOR = -570210402;
        public String password;
        public CheckAuthenticationPassword() {}
        public CheckAuthenticationPassword(String password) { this.password = password; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class LogOut extends Function<Ok> {
        public static final int CONSTRUCTOR = -1536328881;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    // --- Files & Media Primitives ---
    public static class LocalFile extends Object {
        public static final int CONSTRUCTOR = 100181685;
        public String path;
        public boolean canBeDownloaded;
        public boolean canBeDeleted;
        public boolean isDownloadingActive;
        public boolean isDownloadingCompleted;
        public long downloadOffset;
        public long downloadedPrefixSize;
        public long downloadedSize;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class RemoteFile extends Object {
        public static final int CONSTRUCTOR = -562109459;
        public String id;
        public String uniqueId;
        public boolean isUploadingActive;
        public boolean isUploadingCompleted;
        public long uploadedSize;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class File extends Object {
        public static final int CONSTRUCTOR = 732754728;
        public int id;
        public long size;
        public long expectedSize;
        public LocalFile local;
        public RemoteFile remote;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class DownloadFile extends Function<File> {
        public static final int CONSTRUCTOR = 1978458732;
        public int fileId;
        public int priority;
        public long offset;
        public long limit;
        public boolean synchronous;
        public DownloadFile() {}
        public DownloadFile(int fileId, int priority, long offset, long limit, boolean synchronous) {
            this.fileId = fileId;
            this.priority = priority;
            this.offset = offset;
            this.limit = limit;
            this.synchronous = synchronous;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class TextEntity extends Object {
        public static final int CONSTRUCTOR = 445719681;
        public int offset;
        public int length;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class FormattedText extends Object {
        public static final int CONSTRUCTOR = -1199154429;
        public String text;
        public TextEntity[] entities;
        public FormattedText() {}
        public FormattedText(String text, TextEntity[] entities) {
            this.text = text;
            this.entities = entities;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Minithumbnail extends Object {
        public static final int CONSTRUCTOR = -1077273196;
        public int width;
        public int height;
        public byte[] data;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class PhotoSize extends Object {
        public static final int CONSTRUCTOR = -1392056565;
        public String type;
        public File photo;
        public int width;
        public int height;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Photo extends Object {
        public static final int CONSTRUCTOR = -1039778079;
        public boolean hasStickers;
        public Minithumbnail minithumbnail;
        public PhotoSize[] sizes;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Document extends Object {
        public static final int CONSTRUCTOR = 720601902;
        public String fileName;
        public String mimeType;
        public Minithumbnail minithumbnail;
        public File document;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class VoiceNote extends Object {
        public static final int CONSTRUCTOR = 1480786919;
        public int duration;
        public byte[] waveform;
        public String mimeType;
        public File voice;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public abstract static class StickerFormat extends Object {}
    public static class StickerFormatWebp extends StickerFormat {
        public static final int CONSTRUCTOR = 1691850897;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class StickerFormatTgs extends StickerFormat {
        public static final int CONSTRUCTOR = -1968737328;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class StickerFormatWebm extends StickerFormat {
        public static final int CONSTRUCTOR = 1492478295;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Thumbnail extends Object {
        public static final int CONSTRUCTOR = -682112205;
        public int width;
        public int height;
        public File file;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Sticker extends Object {
        public static final int CONSTRUCTOR = 1439491645;
        public long id;
        public long setId;
        public int width;
        public int height;
        public String emoji;
        public StickerFormat format;
        public Thumbnail thumbnail;
        public File sticker;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    // --- Folders & Chats (Step 2) ---
    public abstract static class ChatList extends Object {}
    public static class ChatListMain extends ChatList {
        public static final int CONSTRUCTOR = -400991372;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ChatListArchive extends ChatList {
        public static final int CONSTRUCTOR = -65773828;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ChatListFolder extends ChatList {
        public static final int CONSTRUCTOR = -492290524;
        public int chatFolderId;
        public ChatListFolder() {}
        public ChatListFolder(int chatFolderId) { this.chatFolderId = chatFolderId; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class ChatFolderName extends Object {
        public static final int CONSTRUCTOR = 702016866;
        public FormattedText text;
        public boolean animateCustomEmoji;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ChatFolderInfo extends Object {
        public static final int CONSTRUCTOR = 821249124;
        public int id;
        public ChatFolderName name;
        public String iconName;
        public int colorId;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ChatPosition extends Object {
        public static final int CONSTRUCTOR = -1146652679;
        public ChatList list;
        public long order;
        public boolean isPinned;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ChatPhotoInfo extends Object {
        public static final int CONSTRUCTOR = 1197523751;
        public File small;
        public File big;
        public Minithumbnail minithumbnail;
        public boolean hasAnimation;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class DraftMessage extends Object {
        public static final int CONSTRUCTOR = -996873201;
        public int date;
        public InputMessageContent inputMessageText;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Chat extends Object {
        public static final int CONSTRUCTOR = -1685940148;
        public long id;
        public String title;
        public ChatPhotoInfo photo;
        public ChatPosition[] positions;
        public Message lastMessage;
        public int unreadCount;
        public long lastReadInboxMessageId;
        public long lastReadOutboxMessageId;
        public int unreadMentionCount;
        public DraftMessage draftMessage;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class LoadChats extends Function<Ok> {
        public static final int CONSTRUCTOR = 1202641022;
        public ChatList chatList;
        public int limit;
        public LoadChats() {}
        public LoadChats(ChatList chatList, int limit) {
            this.chatList = chatList;
            this.limit = limit;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class GetChat extends Function<Chat> {
        public static final int CONSTRUCTOR = -700789865;
        public long chatId;
        public GetChat() {}
        public GetChat(long chatId) { this.chatId = chatId; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class OpenChat extends Function<Ok> {
        public static final int CONSTRUCTOR = -1151080909;
        public long chatId;
        public OpenChat() {}
        public OpenChat(long chatId) { this.chatId = chatId; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class CloseChat extends Function<Ok> {
        public static final int CONSTRUCTOR = 626029824;
        public long chatId;
        public CloseChat() {}
        public CloseChat(long chatId) { this.chatId = chatId; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    // --- Messages & Sending (Step 3) ---
    public abstract static class MessageSender extends Object {}
    public static class MessageSenderUser extends MessageSender {
        public static final int CONSTRUCTOR = -336109341;
        public long userId;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageSenderChat extends MessageSender {
        public static final int CONSTRUCTOR = -239660751;
        public long chatId;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public abstract static class MessageSendingState extends Object {}
    public static class MessageSendingStatePending extends MessageSendingState {
        public static final int CONSTRUCTOR = -1028633060;
        public int sendingId;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageSendingStateFailed extends MessageSendingState {
        public static final int CONSTRUCTOR = -1536247228;
        public Error error;
        public boolean canRetry;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public abstract static class MessageContent extends Object {}
    public static class MessageText extends MessageContent {
        public static final int CONSTRUCTOR = 1989037971;
        public FormattedText text;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessagePhoto extends MessageContent {
        public static final int CONSTRUCTOR = -1397051193;
        public Photo photo;
        public FormattedText caption;
        public boolean isSecret;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageDocument extends MessageContent {
        public static final int CONSTRUCTOR = -598290642;
        public Document document;
        public FormattedText caption;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageVoiceNote extends MessageContent {
        public static final int CONSTRUCTOR = 2027796191;
        public VoiceNote voiceNote;
        public FormattedText caption;
        public boolean isListened;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageSticker extends MessageContent {
        public static final int CONSTRUCTOR = -1834597926;
        public Sticker sticker;
        public boolean isPremium;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageVideoNote extends MessageContent {
        public static final int CONSTRUCTOR = 61074281;
        public int duration;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class MessageAnimation extends MessageContent {
        public static final int CONSTRUCTOR = 1109031410;
        public FormattedText caption;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class Message extends Object {
        public static final int CONSTRUCTOR = -1187713004;
        public long id;
        public MessageSender senderId;
        public long chatId;
        public MessageSendingState sendingState;
        public boolean isOutgoing;
        public int date;
        public int editDate;
        public MessageContent content;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class Messages extends Object {
        public static final int CONSTRUCTOR = 1899376589;
        public int totalCount;
        public Message[] messages;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class GetChatHistory extends Function<Messages> {
        public static final int CONSTRUCTOR = -899961950;
        public long chatId;
        public long fromMessageId;
        public int offset;
        public int limit;
        public boolean onlyLocal;
        public GetChatHistory() {}
        public GetChatHistory(long chatId, long fromMessageId, int offset, int limit, boolean onlyLocal) {
            this.chatId = chatId;
            this.fromMessageId = fromMessageId;
            this.offset = offset;
            this.limit = limit;
            this.onlyLocal = onlyLocal;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class ViewMessages extends Function<Ok> {
        public static final int CONSTRUCTOR = 1581001915;
        public long chatId;
        public long[] messageIds;
        public boolean forceRead;
        public ViewMessages() {}
        public ViewMessages(long chatId, long[] messageIds, boolean forceRead) {
            this.chatId = chatId;
            this.messageIds = messageIds;
            this.forceRead = forceRead;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public abstract static class InputFile extends Object {}
    public static class InputFileLocal extends InputFile {
        public static final int CONSTRUCTOR = -236684776;
        public String path;
        public InputFileLocal() {}
        public InputFileLocal(String path) { this.path = path; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class InputFileId extends InputFile {
        public static final int CONSTRUCTOR = 1828785563;
        public int id;
        public InputFileId() {}
        public InputFileId(int id) { this.id = id; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public abstract static class InputMessageContent extends Object {}
    public static class InputMessageText extends InputMessageContent {
        public static final int CONSTRUCTOR = -471261199;
        public FormattedText text;
        public boolean clearDraft;
        public InputMessageText() {}
        public InputMessageText(FormattedText text, boolean clearDraft) {
            this.text = text;
            this.clearDraft = clearDraft;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class InputMessagePhoto extends InputMessageContent {
        public static final int CONSTRUCTOR = -1768409427;
        public InputFile photo;
        public int width;
        public int height;
        public FormattedText caption;
        public InputMessagePhoto() {}
        public InputMessagePhoto(InputFile photo, int width, int height, FormattedText caption) {
            this.photo = photo;
            this.width = width;
            this.height = height;
            this.caption = caption;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class MessageSendOptions extends Object {
        public static final int CONSTRUCTOR = -1512922414;
        public boolean disableNotification;
        public boolean fromBackground;
        public MessageSendOptions() {}
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class SendMessage extends Function<Message> {
        public static final int CONSTRUCTOR = -1390066849;
        public long chatId;
        public long messageThreadId;
        public MessageSendOptions options;
        public InputMessageContent inputMessageContent;
        public SendMessage() {}
        public SendMessage(
                long chatId,
                long messageThreadId,
                MessageSendOptions options,
                InputMessageContent inputMessageContent
        ) {
            this.chatId = chatId;
            this.messageThreadId = messageThreadId;
            this.options = options;
            this.inputMessageContent = inputMessageContent;
        }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class User extends Object {
        public static final int CONSTRUCTOR = -209184771;
        public long id;
        public String firstName;
        public String lastName;
        public String username;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class GetUser extends Function<User> {
        public static final int CONSTRUCTOR = -740060214;
        public long userId;
        public GetUser() {}
        public GetUser(long userId) { this.userId = userId; }
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    // --- Core & Realtime Updates ---
    public abstract static class Update extends Object {}
    public static class UpdateAuthorizationState extends Update {
        public static final int CONSTRUCTOR = -1667705212;
        public AuthorizationState authorizationState;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public abstract static class ConnectionState extends Object {}
    public static class ConnectionStateWaitingForNetwork extends ConnectionState {
        public static final int CONSTRUCTOR = 1168937345;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ConnectionStateConnectingToProxy extends ConnectionState {
        public static final int CONSTRUCTOR = -1392461466;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ConnectionStateConnecting extends ConnectionState {
        public static final int CONSTRUCTOR = -734688602;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ConnectionStateUpdating extends ConnectionState {
        public static final int CONSTRUCTOR = -1696469620;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class ConnectionStateReady extends ConnectionState {
        public static final int CONSTRUCTOR = 442706367;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateConnectionState extends Update {
        public static final int CONSTRUCTOR = 277801679;
        public ConnectionState state;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class UpdateFile extends Update {
        public static final int CONSTRUCTOR = 1090079628;
        public File file;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatFolders extends Update {
        public static final int CONSTRUCTOR = 409986431;
        public ChatFolderInfo[] chatFolders;
        public int mainChatListPosition;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateNewChat extends Update {
        public static final int CONSTRUCTOR = -2054698967;
        public Chat chat;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatTitle extends Update {
        public static final int CONSTRUCTOR = -996038466;
        public long chatId;
        public String title;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatPhoto extends Update {
        public static final int CONSTRUCTOR = -222382026;
        public long chatId;
        public ChatPhotoInfo photo;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatPosition extends Update {
        public static final int CONSTRUCTOR = -1539537242;
        public long chatId;
        public ChatPosition position;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatLastMessage extends Update {
        public static final int CONSTRUCTOR = 964417574;
        public long chatId;
        public Message lastMessage;
        public ChatPosition[] positions;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatReadInbox extends Update {
        public static final int CONSTRUCTOR = 859898283;
        public long chatId;
        public long lastReadInboxMessageId;
        public int unreadCount;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatReadOutbox extends Update {
        public static final int CONSTRUCTOR = 716451608;
        public long chatId;
        public long lastReadOutboxMessageId;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateChatDraftMessage extends Update {
        public static final int CONSTRUCTOR = -372185921;
        public long chatId;
        public DraftMessage draftMessage;
        public ChatPosition[] positions;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }

    public static class UpdateNewMessage extends Update {
        public static final int CONSTRUCTOR = -2102670718;
        public Message message;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateMessageSendSucceeded extends Update {
        public static final int CONSTRUCTOR = -788865442;
        public Message message;
        public long oldMessageId;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateMessageSendFailed extends Update {
        public static final int CONSTRUCTOR = 359204457;
        public Message message;
        public long oldMessageId;
        public Error error;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateMessageContent extends Update {
        public static final int CONSTRUCTOR = -742632820;
        public long chatId;
        public long messageId;
        public MessageContent newContent;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateDeleteMessages extends Update {
        public static final int CONSTRUCTOR = -1020596762;
        public long chatId;
        public long[] messageIds;
        public boolean isPermanent;
        public boolean fromCache;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
    public static class UpdateUser extends Update {
        public static final int CONSTRUCTOR = 1236386396;
        public User user;
        @Override public int getConstructor() { return CONSTRUCTOR; }
    }
}
