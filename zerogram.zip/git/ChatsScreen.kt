package app.zerogram.feature.chats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.zerogram.core.designsystem.LocalZeroGramColors
import app.zerogram.core.designsystem.rememberLocalImageBitmap
import app.zerogram.core.tdlib.ChatsRepository
import app.zerogram.core.tdlib.TdLibManager

@Composable
fun ChatsRoute(
    tdLibManager: TdLibManager,
    chatsRepository: ChatsRepository,
    onOpenChat: (chatId: Long, title: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val viewModel: ChatsViewModel = viewModel(
        factory = ChatsViewModel.factory(tdLibManager, chatsRepository),
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    ChatsContent(
        state = state,
        onIntent = viewModel::onIntent,
        onOpenChat = onOpenChat,
        modifier = modifier,
    )
}

@Composable
fun ChatsContent(
    state: ChatsUiState,
    onIntent: (ChatsIntent) -> Unit,
    onOpenChat: (chatId: Long, title: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalZeroGramColors.current
    val listState = rememberLazyListState()

    val shouldLoadMore by remember {
        derivedStateOf {
            val layout = listState.layoutInfo
            val total = layout.totalItemsCount
            val lastVisible = layout.visibleItemsInfo.lastOrNull()?.index ?: 0
            total > 0 && lastVisible >= total - 8
        }
    }

    LaunchedEffect(shouldLoadMore, state.selectedFolderId) {
        if (shouldLoadMore) {
            onIntent(ChatsIntent.ReachListTail)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.backgroundAmoled),
    ) {
        // Minimal Top Header (Zero Stories bar, Zero Bot MiniApp banners)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.surfaceTopBar)
                .statusBarsPadding()
                .height(52.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = state.headerStatus,
                color = colors.textPrimary,
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { onIntent(ChatsIntent.LogOut) }) {
                Text(
                    text = "Выйти",
                    color = colors.textSecondary,
                    fontSize = 13.sp,
                )
            }
        }

        // Lightweight Chat Folder Tabs (LazyRow + drawBehind pill, zero Heavy TabRow subcomposition)
        FolderTabsBar(
            folders = state.folders,
            selectedFolderId = state.selectedFolderId,
            onSelectFolder = { onIntent(ChatsIntent.SelectFolder(it)) },
        )

        // 120 Hz Dialogs LazyColumn with stable keys & uniform contentType
        if (state.dialogs.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = if (state.isSyncingInitialList) {
                        "Синхронизация чатов…"
                    } else {
                        "В этой папке пока нет диалогов"
                    },
                    color = colors.textSecondary,
                    fontSize = 14.sp,
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
            ) {
                items(
                    items = state.dialogs,
                    key = { it.chatId },
                    contentType = { "dialog_row" },
                ) { dialog ->
                    DialogItemRow(
                        dialog = dialog,
                        onClick = { onOpenChat(dialog.chatId, dialog.title) },
                    )
                }
            }
        }
    }
}

@Composable
private fun FolderTabsBar(
    folders: kotlinx.collections.immutable.ImmutableList<FolderTabUi>,
    selectedFolderId: Int?,
    onSelectFolder: (Int?) -> Unit,
) {
    val colors = LocalZeroGramColors.current
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surfaceTopBar)
            .drawBehind {
                drawLine(
                    color = colors.dividerHairline,
                    start = Offset(0f, size.height - 1f),
                    end = Offset(size.width, size.height - 1f),
                    strokeWidth = 1f,
                )
            },
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(
            items = folders,
            key = { it.folderId ?: -1 },
            contentType = { "folder_tab" },
        ) { tab ->
            val selected = tab.folderId == selectedFolderId
            val pillFill = if (selected) colors.accentMuted else colors.surfaceCard
            val textColor = if (selected) colors.accentPrimary else colors.textSecondary

            Row(
                modifier = Modifier
                    .drawBehind {
                        drawRoundRect(
                            color = pillFill,
                            cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                        )
                    }
                    .clickable { onSelectFolder(tab.folderId) }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = tab.title,
                    color = textColor,
                    fontSize = 14.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                )
                if (tab.unreadChatsCount > 0) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tab.unreadChatsCount.toString(),
                        color = colors.backgroundAmoled,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .drawBehind {
                                drawRoundRect(
                                    color = if (selected) colors.accentPrimary else colors.textSecondary,
                                    cornerRadius = CornerRadius(9.dp.toPx(), 9.dp.toPx()),
                                )
                            }
                            .padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                }
            }
        }
    }
}

/**
 * Single flat Row layout for dialog items — zero Card/Surface wrappers,
 * hairline separator drawn directly in [drawBehind].
 */
@Composable
private fun DialogItemRow(
    dialog: DialogRowUi,
    onClick: () -> Unit,
) {
    val colors = LocalZeroGramColors.current
    val avatarBitmap by rememberLocalImageBitmap(
        localPath = dialog.avatarLocalPath,
        targetMaxPx = 144,
        preferOpaqueRgb565 = true,
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .drawBehind {
                val startX = 76.dp.toPx()
                drawLine(
                    color = colors.dividerHairline,
                    start = Offset(startX, size.height - 1f),
                    end = Offset(size.width, size.height - 1f),
                    strokeWidth = 1f,
                )
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Avatar (50dp)
        Box(
            modifier = Modifier.size(50.dp),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = avatarBitmap
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape),
                )
            } else {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(color = Color(dialog.avatarColorArgb))
                }
                Text(
                    text = dialog.avatarInitials,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = dialog.title,
                    color = colors.textPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(8.dp))
                if (dialog.showOutgoingStatus) {
                    Text(
                        text = if (dialog.isOutgoingRead) "✓✓ " else "✓ ",
                        color = colors.accentPrimary,
                        fontSize = 12.sp,
                    )
                }
                Text(
                    text = dialog.formattedTime,
                    color = colors.textSecondary,
                    fontSize = 12.sp,
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (dialog.isDraft) "Черновик: ${dialog.previewText}" else dialog.previewText,
                    color = if (dialog.isDraft) colors.danger else colors.textSecondary,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )

                if (dialog.unreadCount > 0) {
                    Spacer(modifier = Modifier.width(8.dp))
                    val badgeLabel = if (dialog.unreadCount > 999) "999+" else dialog.unreadCount.toString()
                    Text(
                        text = badgeLabel,
                        color = colors.backgroundAmoled,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .drawBehind {
                                drawRoundRect(
                                    color = colors.unreadBadge,
                                    cornerRadius = CornerRadius(11.dp.toPx(), 11.dp.toPx()),
                                )
                            }
                            .padding(horizontal = 7.dp, vertical = 2.dp),
                    )
                } else if (dialog.isPinned) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "📌",
                        fontSize = 12.sp,
                    )
                }
            }
        }
    }
}
