package app.zerogram.core.tdlib

import android.content.Context
import java.io.File

data class TdLibConfig(
    val initialApiId: Int,
    val initialApiHash: String,
    val databaseDir: File,
    val filesDir: File,
    val systemLanguageCode: String,
    val deviceModel: String,
    val systemVersion: String,
    val appVersion: String,
    val useTestDc: Boolean = false,
)

/**
 * Persists runtime API credentials when the APK was built without compile-time BuildConfig keys,
 * allowing a single universal APK to be configured directly on the phone on first launch.
 */
class ApiCredentialsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        "zerogram_tdlib_creds",
        Context.MODE_PRIVATE,
    )

    fun resolveApiId(compileTimeDefault: Int): Int {
        if (compileTimeDefault > 0) return compileTimeDefault
        return prefs.getInt(KEY_API_ID, 0)
    }

    fun resolveApiHash(compileTimeDefault: String): String {
        if (compileTimeDefault.isNotBlank()) return compileTimeDefault
        return prefs.getString(KEY_API_HASH, "").orEmpty()
    }

    fun save(apiId: Int, apiHash: String) {
        prefs.edit()
            .putInt(KEY_API_ID, apiId)
            .putString(KEY_API_HASH, apiHash.trim())
            .apply()
    }

    companion object {
        private const val KEY_API_ID = "api_id"
        private const val KEY_API_HASH = "api_hash"
    }
}
