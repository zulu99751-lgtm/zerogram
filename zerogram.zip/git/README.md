# ZeroGram — Полная реализация (Шаги 1–3)

Сверхлегкий альтернативный клиент Telegram под Android (`arm64-v8a`, 120 Гц, AMOLED `#000000`, концепция Zero-Bloat).

## Ссылки на документацию используемых технологий
- Нативный движок: [TDLib Repository](https://github.com/tdlib/td), [TDLib Android Build Guide](https://github.com/tdlib/td/blob/master/example/android/README.md), [`org.drinkless.tdlib.Client`](https://github.com/tdlib/td/blob/master/example/java/org/drinkless/tdlib/Client.java), [`loadChats`](https://core.telegram.org/tdlib/docs/classtd_1_1td__api_1_1load_chats.html), [`getChatHistory`](https://core.telegram.org/tdlib/docs/classtd_1_1td__api_1_1get_chat_history.html)
- UI и стабильность: [Jetpack Compose Stability](https://developer.android.com/develop/ui/compose/performance/stability), [kotlinx.collections.immutable](https://github.com/Kotlin/kotlinx.collections.immutable), [Paging 3 Compose](https://developer.android.com/topic/libraries/architecture/paging/v3-overview)
- Медиа и системные API: [Android `PlaybackParams.setSpeed`](https://developer.android.com/reference/android/media/PlaybackParams) (ускорение голосовых `1x / 1.5x / 2x`), [Android Photo Picker (`PickVisualMedia`)](https://developer.android.com/training/data-storage/shared/photo-picker)
- Оптимизация релиза: [R8 Full Mode](https://developer.android.com/topic/performance/app-optimization/full-mode), [Baseline Profiles](https://developer.android.com/develop/ui/compose/performance/baseline-profiles)

## Что реализовано по этапам
1. **Архитектура, Gradle и Шаг 1 (`:core:tdlib`, `:feature:auth`, `:app`)**:
   - 8 модулей без рефлексивного DI (`DefaultAppContainer` на ленивых делегатах).
   - `TdLibManager` на выделенном потоке `ZeroGram-TDLib-Actor`, фильтрация Stories / Stars / Gifts / Mini Apps на границе JNI, полная машина авторизации (`WaitTdlibParameters -> WaitPhoneNumber -> WaitCode -> WaitPassword 2FA -> Ready`).
2. **Шаг 2 — Главный экран (`:feature:chats`, `ChatsRepository`)**:
   - Реактивные вкладки папок чатов (`UpdateChatFolders`: `ChatListMain` + пользовательские `ChatListFolder`) с подсчетом непрочитанных диалогов.
   - Детерминированная сортировка чатов `(position.order DESC, chat.id DESC)` на фоновом акторе с коалесценцией кадров (16 мс), кастомные плоские строки диалогов (`drawBehind` без вложенных `Card`/`Surface`), пагинация через `LoadChats` до кода `404`.
3. **Шаг 3 — Экран чата (`:feature:chat`, `ChatMessagesRepository`, `ChatHistoryPagingSource`, `VoicePlayerController`)**:
   - **Мгновенное открытие (0 мс)**: `ZeroGramRoot` удерживает список чатов в памяти без пересоздания при возврате назад, а `hotSliceCache` отдает последние сообщения на первом кадре до завершения первой страницы `Paging 3`.
   - **История на Paging 3**: `ChatHistoryPagingSource` с автоматической догрузкой второй порции при локальном кэш-хите из 1 сообщения и автопометкой прочитанности `ViewMessages`.
   - **Кастомные плоские баблы**: рендеринг фона через `drawBehind`, отправка текста (`InputMessageText`) и фотографий через системный `PickVisualMedia` (`InputMessagePhoto`), статичные `WebP` превью стикеров (анимация только по тапу), голосовые сообщения с декодированием 5-битной волны на один `Canvas` и переключением скорости `1x -> 1.5x -> 2x` на лету через `PlaybackParams`.

## Быстрый старт и проверка сборки локально
1. Поместите предсобранный `libtdjni.so` (`arm64-v8a`) в `core/tdlib/src/main/jniLibs/arm64-v8a/libtdjni.so` и соответствующий сгенерированный `TdApi.java` в `core/tdlib/src/main/java/org/drinkless/tdlib/TdApi.java`.
2. Создайте `local.properties` в корне проекта:
   ```properties
   sdk.dir=/path/to/Android/Sdk
   TDLIB_API_ID=1234567
   TDLIB_API_HASH=your_api_hash
   ```
3. Запустите сборку всех модулей (Debug + агрессивный R8 Release):
   ```bash
   ./scripts/verify_all_modules.sh
   ```
