package app.zerogram.core.common

import android.os.Process
import java.util.concurrent.Executors
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher

/**
 * Explicit coroutine dispatchers for ZeroGram.
 *
 * [tdlibActor] executes on a dedicated single OS thread with elevated priority
 * so JNI calls, dialog-tree sorting, and bloat-update filtering never contend with
 * the 8.33 ms Main UI render budget on 120 Hz screens.
 */
class AppDispatchers(
    val mainImmediate: CoroutineDispatcher = Dispatchers.Main.immediate,
    val io: CoroutineDispatcher = Dispatchers.IO,
    val default: CoroutineDispatcher = Dispatchers.Default,
    val tdlibActor: CoroutineDispatcher = createTdLibActorDispatcher(),
) {
    companion object {
        private fun createTdLibActorDispatcher(): CoroutineDispatcher {
            val executor = Executors.newSingleThreadExecutor { runnable ->
                Thread(
                    {
                        Process.setThreadPriority(Process.THREAD_PRIORITY_MORE_FAVORABLE)
                        runnable.run()
                    },
                    "ZeroGram-TDLib-Actor",
                ).apply {
                    isDaemon = true
                }
            }
            return executor.asCoroutineDispatcher()
        }
    }
}
