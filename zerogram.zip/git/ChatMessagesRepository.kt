package app.zerogram.core.tdlib

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import app.zerogram.core.common.AppDispatchers
import app.zerogram.core.common.FastFormatters
import app.zerogram.core.tdlib.model.ChatMessageItem
import app.zerogram.core.tdlib.model.DomainMessageContent
import app.zerogram.core.tdlib.model.OutgoingDeliveryStatus
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.toImmutableList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.TdApi

/**
 * Step 3 Instant-Open & Paging 3 Chat History Repository.
 *
 * - Keeps an LruCache of the latest messages per chat so opening a dialog renders Frame 1
 *   immediately (0 ms blank screen) before Paging 3 finishes its first async pass.
 * - Maps TDLib messages into lightweight immutable domain models, enforcing static WebP
 *   sticker previews (never auto-downloading .tgs / .webm unless explicitly tapped).
 */
class ChatMessagesRepository(
    context: Context,
    private val tdLibManager: TdLibManager,
    private val mediaFileStore: MediaFileStore,
    private val dispatchers: AppDispatchers,
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.tdlibActor)

    private val userNamesCache = ConcurrentHashMap<Long, String>(256)
    private val lastReadOutboxByChat = ConcurrentHashMap<Long, Long>(128)

    private val hotSliceCache = object : LruCache<Long, ImmutableList<ChatMessageItem>>(48) {}

    @Volatile
    private var activeChatId: Long? = null

    @Volatile
    private var activePagingSource: ChatHistoryPagingSource? = null

    init {
        scope.launch {
            tdLibManager.updates.collect { update ->
                when (update) {
                    is TdApi.UpdateUser -> {
                        val u = update.user ?: return@collect
                        val fullName = "${u.firstName.orEmpty()} ${u.lastName.orEmpty()}".trim()
                        if (fullName.isNotBlank()) {
                            userNamesCache[u.id] = fullName
                        }
                    }
                    is TdApi.UpdateNewChat -> {
                        val c = update.chat ?: return@collect
                        lastReadOutboxByChat[c.id] = c.lastReadOutboxMessageId
                        val last = c.lastMessage
                        if (last != null && hotSliceCache.get(c.id) == null) {
                            hotSliceCache.put(c.id, persistentListOf(mapMessage(last)))
                        }
                    }
                    is TdApi.UpdateChatReadOutbox -> {
                        lastReadOutboxByChat[update.chatId] = update.lastReadOutboxMessageId
                        if (update.chatId == activeChatId) {
                            activePagingSource?.invalidate()
                        }
                    }
                    is TdApi.UpdateNewMessage -> {
                        val m = update.message ?: return@collect
                        prependToHotCache(m)
                        if (m.chatId == activeChatId) {
                            activePagingSource?.invalidate()
                        }
                    }
                    is TdApi.UpdateMessageSendSucceeded -> {
                        val m = update.message ?: return@collect
                        if (m.chatId == activeChatId) {
                            activePagingSource?.invalidate()
                        }
                    }
                    is TdApi.UpdateMessageSendFailed -> {
                        val m = update.message ?: return@collect
                        if (m.chatId == activeChatId) {
                            activePagingSource?.invalidate()
                        }
                    }
                    is TdApi.UpdateMessageContent -> {
                        if (update.chatId == activeChatId) {
                            activePagingSource?.invalidate()
                        }
                    }
                    is TdApi.UpdateDeleteMessages -> {
                        if (!update.fromCache && update.chatId == activeChatId) {
                            activePagingSource?.invalidate()
                        }
                    }
                    is TdApi.UpdateFile -> {
                        if (activeChatId != null && update.file?.local?.isDownloadingCompleted == true) {
                            activePagingSource?.invalidate()
                        }
                    }
                    else -> Unit
                }
            }
        }
    }

    fun getInstantSeedMessages(chatId: Long): ImmutableList<ChatMessageItem> =
        hotSliceCache.get(chatId) ?: persistentListOf()

    fun openChatSession(chatId: Long) {
        activeChatId = chatId
        tdLibManager.sendFireAndForget(TdApi.OpenChat(chatId))
    }

    fun closeChatSession(chatId: Long) {
        if (activeChatId == chatId) {
            activeChatId = null
        }
        tdLibManager.sendFireAndForget(TdApi.CloseChat(chatId))
    }

    fun pagedHistoryFlow(chatId: Long): Flow<PagingData<ChatMessageItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 35,
                initialLoadSize = 40,
                prefetchDistance = 12,
                enablePlaceholders = false,
            ),
            pagingSourceFactory = {
                ChatHistoryPagingSource(
                    chatId = chatId,
                    tdLibManager = tdLibManager,
                    messageMapper = ::mapMessage,
                    onTopSliceLoaded = { topItems ->
                        hotSliceCache.put(chatId, topItems.take(25).toImmutableList())
                    },
                ).also { source ->
                    activePagingSource = source
                }
            },
        ).flow
    }

    suspend fun sendTextMessage(chatId: Long, rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        val formatted = TdApi.FormattedText().apply {
            this.text = text
            this.entities = emptyArray()
        }
        val content = TdApi.InputMessageText().apply {
            this.text = formatted
            this.clearDraft = true
        }
        val request = TdApi.SendMessage().apply {
            this.chatId = chatId
            this.options = TdApi.MessageSendOptions()
            this.inputMessageContent = content
        }
        tdLibManager.send(request)
    }

    suspend fun sendPhotoUri(chatId: Long, contentUri: Uri, caption: String = "") {
        val staged = withContext(dispatchers.io) {
            stagePhotoFromUri(contentUri)
        } ?: return

        val formattedCaption = TdApi.FormattedText().apply {
            this.text = caption.trim()
            this.entities = emptyArray()
        }
        val content = TdApi.InputMessagePhoto().apply {
            this.photo = TdApi.InputFileLocal(staged.file.absolutePath)
            this.width = staged.width
            this.height = staged.height
            this.caption = formattedCaption
        }
        val request = TdApi.SendMessage().apply {
            this.chatId = chatId
            this.options = TdApi.MessageSendOptions()
            this.inputMessageContent = content
        }
        tdLibManager.send(request)
    }

    fun requestMediaDownload(fileId: Int, highPriority: Boolean = true) {
        mediaFileStore.ensureDownloaded(fileId, priority = if (highPriority) 28 else 12)
    }

    private data class StagedPhoto(
        val file: File,
        val width: Int,
        val height: Int,
    )

    private fun stagePhotoFromUri(uri: Uri): StagedPhoto? = runCatching {
        val stagingDir = File(appContext.cacheDir, "outgoing_photos").apply { mkdirs() }
        val target = File(stagingDir, "photo_${System.currentTimeMillis()}.jpg")
        appContext.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output, bufferSize = 16 * 1024)
            }
        } ?: return null

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(target.absolutePath, bounds)
        StagedPhoto(
            file = target,
            width = bounds.outWidth.coerceAtLeast(320),
            height = bounds.outHeight.coerceAtLeast(320),
        )
    }.getOrNull()

    private suspend fun prependToHotCache(msg: TdApi.Message) {
        val mapped = mapMessage(msg)
        val existing = hotSliceCache.get(msg.chatId).orEmpty()
        val updated = buildList(existing.size + 1) {
            add(mapped)
            for (item in existing) {
                if (item.id != mapped.id && size < 25) add(item)
            }
        }.toImmutableList()
        hotSliceCache.put(msg.chatId, updated)
    }

    private suspend fun mapMessage(msg: TdApi.Message): ChatMessageItem {
        val senderName = if (msg.isOutgoing) {
            null
        } else {
            resolveSenderName(msg.senderId)
        }

        val readOutboxId = lastReadOutboxByChat[msg.chatId] ?: 0L
        val status = when {
            !msg.isOutgoing -> OutgoingDeliveryStatus.NONE
            msg.sendingState is TdApi.MessageSendingStatePending -> OutgoingDeliveryStatus.PENDING
            msg.sendingState is TdApi.MessageSendingStateFailed -> OutgoingDeliveryStatus.FAILED
            msg.id <= readOutboxId -> OutgoingDeliveryStatus.READ
            else -> OutgoingDeliveryStatus.SENT_UNREAD
        }

        return ChatMessageItem(
            id = msg.id,
            chatId = msg.chatId,
            senderName = senderName,
            isOutgoing = msg.isOutgoing,
            formattedTime = FastFormatters.formatMessageClock(msg.date),
            deliveryStatus = status,
            content = mapMessageContent(msg.content),
        )
    }

    private suspend fun resolveSenderName(sender: TdApi.MessageSender?): String? = when (sender) {
        is TdApi.MessageSenderUser -> {
            userNamesCache[sender.userId] ?: runCatching {
                val user = tdLibManager.send(TdApi.GetUser(sender.userId))
                "${user.firstName.orEmpty()} ${user.lastName.orEmpty()}".trim()
                    .takeIf { it.isNotBlank() }
                    ?.also { userNamesCache[sender.userId] = it }
            }.getOrNull()
        }
        else -> null
    }

    private fun mapMessageContent(content: TdApi.MessageContent?): DomainMessageContent = when (content) {
        is TdApi.MessageText -> DomainMessageContent.Text(
            body = content.text?.text.orEmpty(),
        )
        is TdApi.MessagePhoto -> {
            val sizes = content.photo?.sizes ?: emptyArray()
            // Pick medium ~800px size rather than huge 4K full-res for 120 Hz scroll efficiency
            val chosen = sizes.firstOrNull { it.width in 400..1280 } ?: sizes.lastOrNull()
            val fileSnap = mediaFileStore.recordFile(chosen?.photo)
            if (fileSnap.fileId != 0 && fileSnap.localPath == null) {
                mediaFileStore.ensureDownloaded(fileSnap.fileId, priority = 14)
            }
            DomainMessageContent.Photo(
                fileId = fileSnap.fileId,
                localPath = fileSnap.localPath,
                width = (chosen?.width ?: 640).coerceAtLeast(120),
                height = (chosen?.height ?: 480).coerceAtLeast(120),
                caption = content.caption?.text.orEmpty(),
                isDownloading = fileSnap.isDownloading,
            )
        }
        is TdApi.MessageVoiceNote -> {
            val vn = content.voiceNote
            val fileSnap = mediaFileStore.recordFile(vn?.voice)
            DomainMessageContent.Voice(
                fileId = fileSnap.fileId,
                localPath = fileSnap.localPath,
                durationSec = vn?.duration ?: 0,
                waveformSamples = decodeVoiceWaveform(vn?.waveform),
                isDownloading = fileSnap.isDownloading,
            )
        }
        is TdApi.MessageSticker -> {
            val st = content.sticker
            val isWebp = st?.format is TdApi.StickerFormatWebp
            // Zero-Bloat policy: only auto-download static WebP or static thumbnail; NEVER auto-fetch TGS/WebM!
            val previewFile = if (isWebp) st?.sticker else st?.thumbnail?.file
            val previewSnap = mediaFileStore.recordFile(previewFile)
            val fullSnap = mediaFileStore.recordFile(st?.sticker)
            if (previewSnap.fileId != 0 && previewSnap.localPath == null) {
                mediaFileStore.ensureDownloaded(previewSnap.fileId, priority = 10)
            }
            DomainMessageContent.Sticker(
                stickerFileId = fullSnap.fileId,
                staticPreviewFileId = previewSnap.fileId,
                staticPreviewLocalPath = previewSnap.localPath,
                animatedLocalPath = if (!isWebp) fullSnap.localPath else null,
                emoji = st?.emoji.orEmpty(),
                width = (st?.width ?: 256).coerceAtLeast(96),
                height = (st?.height ?: 256).coerceAtLeast(96),
                isAnimatedFormat = !isWebp,
            )
        }
        is TdApi.MessageDocument -> {
            val doc = content.document
            val fileSnap = mediaFileStore.recordFile(doc?.document)
            val bytes = doc?.document?.expectedSize?.takeIf { it > 0 } ?: doc?.document?.size ?: 0L
            DomainMessageContent.DocumentFile(
                fileId = fileSnap.fileId,
                localPath = fileSnap.localPath,
                fileName = doc?.fileName?.ifBlank { "Документ" } ?: "Документ",
                sizeLabel = FastFormatters.formatByteSize(bytes),
                isDownloading = fileSnap.isDownloading,
            )
        }
        is TdApi.MessageVideoNote -> DomainMessageContent.VideoNoteStatic(
            durationSec = content.duration,
        )
        else -> DomainMessageContent.Unsupported(label = "Медиавложение")
    }

    /**
     * Decodes Telegram's 5-bit packed voice waveform into 32 normalized [0.15f..1.0f] bar heights.
     */
    private fun decodeVoiceWaveform(raw: ByteArray?): ImmutableList<Float> {
        val barCount = 32
        if (raw == null || raw.isEmpty()) {
            return List(barCount) { idx ->
                0.25f + ((idx * 7) % 10) * 0.06f
            }.toImmutableList()
        }
        val totalSamples = (raw.size * 8) / 5
        if (totalSamples <= 0) return persistentListOf()

        val bars = ArrayList<Float>(barCount)
        for (i in 0 until barCount) {
            val sampleIdx = (i * totalSamples) / barCount
            val bitOffset = sampleIdx * 5
            val byteIdx = bitOffset / 8
            val bitShift = bitOffset % 8
            var value = ((raw[byteIdx].toInt() and 0xFF) ushr bitShift)
            if (bitShift > 3 && byteIdx + 1 < raw.size) {
                value = value or ((raw[byteIdx + 1].toInt() and 0xFF) shl (8 - bitShift))
            }
            val fiveBit = value and 0x1F
            bars.add((fiveBit / 31f).coerceIn(0.15f, 1.0f))
        }
        return bars.toImmutableList()
    }
}
