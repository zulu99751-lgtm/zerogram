package app.zerogram.feature.auth

import androidx.compose.runtime.Immutable
import app.zerogram.core.tdlib.model.CodeDeliveryChannel

enum class AuthStep {
    INITIALIZING,
    API_CREDENTIALS_INPUT,
    SETUP_REQUIRED,
    PHONE_NUMBER,
    VERIFICATION_CODE,
    TWO_FACTOR_PASSWORD,
}

@Immutable
data class AuthUiState(
    val step: AuthStep = AuthStep.INITIALIZING,
    val apiIdInput: String = "",
    val apiHashInput: String = "",
    val phoneInput: String = "+",
    val codeInput: String = "",
    val expectedCodeLength: Int = 5,
    val deliveryChannel: CodeDeliveryChannel = CodeDeliveryChannel.TELEGRAM_APP,
    val passwordInput: String = "",
    val passwordHint: String = "",
    val isPasswordVisible: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val setupDiagnosticMessage: String? = null,
)

sealed interface AuthIntent {
    data class ApiIdChanged(val value: String) : AuthIntent
    data class ApiHashChanged(val value: String) : AuthIntent
    data object SaveApiCredentials : AuthIntent

    data class PhoneChanged(val value: String) : AuthIntent
    data object SubmitPhone : AuthIntent

    data class CodeChanged(val value: String) : AuthIntent
    data object SubmitCode : AuthIntent
    data object ResendCode : AuthIntent

    data class PasswordChanged(val value: String) : AuthIntent
    data object TogglePasswordVisibility : AuthIntent
    data object SubmitPassword : AuthIntent

    data object ClearError : AuthIntent
}
