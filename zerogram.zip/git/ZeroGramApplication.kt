package app.zerogram

import android.app.Application
import app.zerogram.di.AppContainer
import app.zerogram.di.DefaultAppContainer

class ZeroGramApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = DefaultAppContainer(this)
    }
}
