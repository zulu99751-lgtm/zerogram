@echo off
chcp 65001 >nul
echo ========================================================
echo   ZeroGram One-Click APK Builder for Windows 11
echo ========================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build_apk_windows.ps1"
pause
