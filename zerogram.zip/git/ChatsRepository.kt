package app.zerogram.core.tdlib

import app.zerogram.core.common.AppDispatchers
import app.zerogram.core.common.FastFormatters
import app.zerogram.core.tdlib.model.AuthState
import app.zerogram.core.tdlib.model.ChatFolderTab
import app.zerogram.core.tdlib.model.DialogSummary
import app.zerogram.core.tdlib.model.TdLibException
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.toImmutableList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Step 2 Reactive Chats & Folders Engine.
 *
 * Maintains all known chats on [AppDispatchers.tdlibActor] and emits pre-sorted,
 * Compose-ready [ImmutableList] snapshots throttled to <= 60 emissions/sec during initial sync.
 */
class ChatsRepository(
    private val tdLibManager: TdLibManager,
    private val mediaFileStore: MediaFileStore,
    dispatchers: AppDispatchers,
) {
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.tdlibActor)

    private class MutableChatRecord(
        val id: Long,
        var title: String,
        var avatarFileId: Int?,
        var positions: Array<TdApi.ChatPosition>,
        var lastMessage: TdApi.Message?,
        var draftMessage: TdApi.DraftMessage?,
        var unreadCount: Int,
        var lastReadOutboxMessageId: Long,
    )

    private val chatsById = HashMap<Long, MutableChatRecord>(256)
    private var rawFolders: Array<TdApi.ChatFolderInfo> = emptyArray()
    private val exhaustedLists = HashSet<Int?>()
    private var snapshotDirty = false

    private val _folders = MutableStateFlow<ImmutableList<ChatFolderTab>>(
        persistentListOf(ChatFolderTab(folderId = null, title = "Все чаты", unreadChatsCount = 0)),
    )
    val folders: StateFlow<ImmutableList<ChatFolderTab>> = _folders.asStateFlow()

    // Key: folderId (null = Main list) -> sorted ImmutableList<DialogSummary>
    private val _dialogsByFolder = MutableStateFlow<Map<Int?, ImmutableList<DialogSummary>>>(emptyMap())

    init {
        scope.launch {
            tdLibManager.authState.collect { auth ->
                if (auth is AuthState.Ready) {
                    loadMoreChats(folderId = null, limit = 40)
                } else if (auth is AuthState.Closed) {
                    chatsById.clear()
                    exhaustedLists.clear()
                    _dialogsByFolder.value = emptyMap()
                }
            }
        }

        scope.launch {
            tdLibManager.updates.collect { update ->
                handleUpdate(update)
            }
        }

        // Coalesced snapshot publisher (~16 ms frame cadence when dirty) avoids UI flood on cold sync
        scope.launch {
            while (true) {
                delay(16L)
                if (snapshotDirty) {
                    snapshotDirty = false
                    publishSnapshots()
                }
            }
        }
    }

    fun observeDialogs(folderId: Int?): Flow<ImmutableList<DialogSummary>> =
        _dialogsByFolder
            .map { map -> map[folderId] ?: persistentListOf() }
            .distinctUntilChanged()

    fun getCachedChatTitle(chatId: Long): String? = chatsById[chatId]?.title

    suspend fun loadMoreChats(folderId: Int?, limit: Int = 40) {
        if (exhaustedLists.contains(folderId)) return
        val chatList: TdApi.ChatList = if (folderId == null) {
            TdApi.ChatListMain()
        } else {
            TdApi.ChatListFolder(folderId)
        }
        try {
            tdLibManager.send(TdApi.LoadChats(chatList, limit))
        } catch (e: TdLibException) {
            // Per TDLib docs: HTTP/code 404 from LoadChats means all chats in this list are loaded
            if (e.code == 404) {
                exhaustedLists.add(folderId)
            }
        }
    }

    private fun handleUpdate(update: TdApi.Update) {
        when (update) {
            is TdApi.UpdateChatFolders -> {
                rawFolders = update.chatFolders ?: emptyArray()
                snapshotDirty = true
            }
            is TdApi.UpdateNewChat -> {
                val c = update.chat ?: return
                val smallFile = c.photo?.small
                mediaFileStore.recordFile(smallFile)
                if (smallFile != null && smallFile.id != 0) {
                    mediaFileStore.ensureDownloaded(smallFile.id, priority = 8)
                }
                chatsById[c.id] = MutableChatRecord(
                    id = c.id,
                    title = c.title.orEmpty(),
                    avatarFileId = smallFile?.id,
                    positions = c.positions ?: emptyArray(),
                    lastMessage = c.lastMessage,
                    draftMessage = c.draftMessage,
                    unreadCount = c.unreadCount,
                    lastReadOutboxMessageId = c.lastReadOutboxMessageId,
                )
                snapshotDirty = true
            }
            is TdApi.UpdateChatTitle -> {
                chatsById[update.chatId]?.let {
                    it.title = update.title.orEmpty()
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateChatPhoto -> {
                chatsById[update.chatId]?.let {
                    val small = update.photo?.small
                    mediaFileStore.recordFile(small)
                    it.avatarFileId = small?.id
                    if (small != null && small.id != 0) {
                        mediaFileStore.ensureDownloaded(small.id, priority = 8)
                    }
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateChatPosition -> {
                val pos = update.position ?: return
                chatsById[update.chatId]?.let { record ->
                    record.positions = upsertPosition(record.positions, pos)
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateChatLastMessage -> {
                chatsById[update.chatId]?.let { record ->
                    record.lastMessage = update.lastMessage
                    if (update.positions != null) {
                        record.positions = update.positions
                    }
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateChatReadInbox -> {
                chatsById[update.chatId]?.let { record ->
                    record.unreadCount = update.unreadCount
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateChatReadOutbox -> {
                chatsById[update.chatId]?.let { record ->
                    record.lastReadOutboxMessageId = update.lastReadOutboxMessageId
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateChatDraftMessage -> {
                chatsById[update.chatId]?.let { record ->
                    record.draftMessage = update.draftMessage
                    if (update.positions != null) {
                        record.positions = update.positions
                    }
                    snapshotDirty = true
                }
            }
            is TdApi.UpdateFile -> {
                val fid = update.file?.id ?: return
                if (chatsById.values.any { it.avatarFileId == fid }) {
                    snapshotDirty = true
                }
            }
            else -> Unit
        }
    }

    private fun upsertPosition(
        current: Array<TdApi.ChatPosition>,
        updated: TdApi.ChatPosition,
    ): Array<TdApi.ChatPosition> {
        val filtered = current.filterNot { sameChatList(it.list, updated.list) }
        return if (updated.order == 0L) {
            filtered.toTypedArray()
        } else {
            (filtered + updated).toTypedArray()
        }
    }

    private fun sameChatList(a: TdApi.ChatList?, b: TdApi.ChatList?): Boolean = when {
        a is TdApi.ChatListMain && b is TdApi.ChatListMain -> true
        a is TdApi.ChatListArchive && b is TdApi.ChatListArchive -> true
        a is TdApi.ChatListFolder && b is TdApi.ChatListFolder -> a.chatFolderId == b.chatFolderId
        else -> false
    }

    private fun publishSnapshots() {
        val folderIds = ArrayList<Int?>(rawFolders.size + 1)
        folderIds.add(null)
        for (folder in rawFolders) {
            folderIds.add(folder.id)
        }

        val newMap = HashMap<Int?, ImmutableList<DialogSummary>>(folderIds.size)
        val newTabs = ArrayList<ChatFolderTab>(folderIds.size)

        for (fid in folderIds) {
            val ranked = ArrayList<Pair<TdApi.ChatPosition, MutableChatRecord>>()
            var unreadChatsInFolder = 0

            for (record in chatsById.values) {
                val pos = findPosition(record.positions, fid) ?: continue
                if (pos.order == 0L) continue
                ranked.add(pos to record)
                if (record.unreadCount > 0) unreadChatsInFolder++
            }

            // Deterministic TDLib descending sort: (position.order DESC, chat.id DESC)
            ranked.sortWith { a, b ->
                val orderCmp = b.first.order.compareTo(a.first.order)
                if (orderCmp != 0) orderCmp else b.second.id.compareTo(a.second.id)
            }

            val summaries = ArrayList<DialogSummary>(ranked.size)
            for ((pos, rec) in ranked) {
                summaries.add(toDialogSummary(rec, pos.isPinned))
            }
            newMap[fid] = summaries.toImmutableList()

            val title = if (fid == null) {
                "Все чаты"
            } else {
                rawFolders.firstOrNull { it.id == fid }
                    ?.name?.text?.text
                    ?.takeIf { it.isNotBlank() }
                    ?: "Папка"
            }
            newTabs.add(
                ChatFolderTab(
                    folderId = fid,
                    title = title,
                    unreadChatsCount = unreadChatsInFolder,
                ),
            )
        }

        _folders.value = newTabs.toImmutableList()
        _dialogsByFolder.value = newMap
    }

    private fun findPosition(
        positions: Array<TdApi.ChatPosition>,
        folderId: Int?,
    ): TdApi.ChatPosition? {
        for (pos in positions) {
            val list = pos.list
            if (folderId == null && list is TdApi.ChatListMain) return pos
            if (folderId != null && list is TdApi.ChatListFolder && list.chatFolderId == folderId) {
                return pos
            }
        }
        return null
    }

    private fun toDialogSummary(
        rec: MutableChatRecord,
        isPinned: Boolean,
    ): DialogSummary {
        val draftInput = rec.draftMessage?.inputMessageText as? TdApi.InputMessageText
        val draftText = draftInput?.text?.text?.takeIf { it.isNotBlank() }
        val lastMsg = rec.lastMessage

        val preview = when {
            draftText != null -> draftText.replace('
', ' ')
            lastMsg != null -> formatMessagePreview(lastMsg.content)
            else -> "Нет сообщений"
        }

        val timestampSec = rec.draftMessage?.date?.takeIf { it > 0 }
            ?: lastMsg?.date
            ?: 0

        val isOutgoing = lastMsg?.isOutgoing == true && draftText == null
        val isOutgoingRead = isOutgoing && lastMsg != null && lastMsg.id <= rec.lastReadOutboxMessageId

        return DialogSummary(
            chatId = rec.id,
            title = rec.title.ifBlank { "Чат #${rec.id}" },
            avatarInitials = FastFormatters.initialsForTitle(rec.title),
            avatarColorArgb = FastFormatters.avatarColorForId(rec.id),
            avatarFileId = rec.avatarFileId,
            avatarLocalPath = mediaFileStore.getLocalPath(rec.avatarFileId),
            previewText = preview,
            isDraft = draftText != null,
            formattedTime = FastFormatters.formatUnixTimeShort(timestampSec),
            unreadCount = rec.unreadCount,
            isPinned = isPinned,
            showOutgoingStatus = isOutgoing,
            isOutgoingRead = isOutgoingRead,
        )
    }

    companion object {
        fun formatMessagePreview(content: TdApi.MessageContent?): String = when (content) {
            is TdApi.MessageText -> content.text?.text.orEmpty().replace('
', ' ')
            is TdApi.MessagePhoto -> {
                val cap = content.caption?.text.orEmpty().replace('
', ' ')
                if (cap.isNotBlank()) "Фото · $cap" else "Фотография"
            }
            is TdApi.MessageVoiceNote -> {
                val sec = content.voiceNote?.duration ?: 0
                "Голосовое сообщение (${FastFormatters.formatDurationSeconds(sec)})"
            }
            is TdApi.MessageSticker -> {
                val emoji = content.sticker?.emoji.orEmpty()
                "$emoji Стикер".trim()
            }
            is TdApi.MessageDocument -> {
                val name = content.document?.fileName?.takeIf { it.isNotBlank() } ?: "Файл"
                "Файл · $name"
            }
            is TdApi.MessageVideoNote -> "Видеосообщение"
            is TdApi.MessageAnimation -> "GIF"
            else -> "Сообщение"
        }
    }
}
