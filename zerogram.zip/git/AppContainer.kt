package app.zerogram.di

import android.content.Context
import android.os.Build
import app.zerogram.BuildConfig
import app.zerogram.core.common.AppDispatchers
import app.zerogram.core.tdlib.ApiCredentialsStore
import app.zerogram.core.tdlib.BuildConfig as TdLibBuildConfig
import app.zerogram.core.tdlib.ChatMessagesRepository
import app.zerogram.core.tdlib.ChatsRepository
import app.zerogram.core.tdlib.MediaFileStore
import app.zerogram.core.tdlib.TdLibConfig
import app.zerogram.core.tdlib.TdLibManager
import app.zerogram.feature.chat.VoicePlayerController
import java.io.File
import java.util.Locale

interface AppContainer {
    val dispatchers: AppDispatchers
    val tdLibManager: TdLibManager
    val mediaFileStore: MediaFileStore
    val chatsRepository: ChatsRepository
    val chatMessagesRepository: ChatMessagesRepository
    val voicePlayerController: VoicePlayerController
}

class DefaultAppContainer(
    context: Context,
) : AppContainer {
    private val appContext = context.applicationContext

    override val dispatchers: AppDispatchers by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppDispatchers()
    }

    override val tdLibManager: TdLibManager by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        val config = TdLibConfig(
            initialApiId = TdLibBuildConfig.TDLIB_API_ID,
            initialApiHash = TdLibBuildConfig.TDLIB_API_HASH,
            databaseDir = File(appContext.noBackupFilesDir, "tdlib_db"),
            filesDir = File(appContext.cacheDir, "tdlib_media"),
            systemLanguageCode = Locale.getDefault().language.ifBlank { "ru" },
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            systemVersion = "Android ${Build.VERSION.RELEASE}",
            appVersion = BuildConfig.VERSION_NAME,
        )
        TdLibManager(
            config = config,
            credentialsStore = ApiCredentialsStore(appContext),
            dispatchers = dispatchers,
        )
    }

    override val mediaFileStore: MediaFileStore by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        MediaFileStore(tdLibManager = tdLibManager, dispatchers = dispatchers)
    }

    override val chatsRepository: ChatsRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        ChatsRepository(
            tdLibManager = tdLibManager,
            mediaFileStore = mediaFileStore,
            dispatchers = dispatchers,
        )
    }

    override val chatMessagesRepository: ChatMessagesRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        ChatMessagesRepository(
            context = appContext,
            tdLibManager = tdLibManager,
            mediaFileStore = mediaFileStore,
            dispatchers = dispatchers,
        )
    }

    override val voicePlayerController: VoicePlayerController by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        VoicePlayerController(dispatchers = dispatchers)
    }
}
