package app.zerogram.core.tdlib

import app.zerogram.core.common.AppDispatchers
import app.zerogram.core.tdlib.model.AuthState
import app.zerogram.core.tdlib.model.CodeDeliveryChannel
import app.zerogram.core.tdlib.model.NetworkSyncState
import app.zerogram.core.tdlib.model.TdLibException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi

/**
 * ZeroGram reactive TDLib engine.
 * Supports both compile-time API keys and in-app runtime API_ID / API_HASH onboarding
 * so a universal APK works out of the box without editing Gradle properties.
 */
class TdLibManager(
    private val config: TdLibConfig,
    private val credentialsStore: ApiCredentialsStore,
    private val dispatchers: AppDispatchers,
) {
    private val actorScope = CoroutineScope(SupervisorJob() + dispatchers.tdlibActor)
    private val nativeLoaded = AtomicBoolean(false)

    @Volatile
    private var client: Client? = null

    private var activeApiId: Int = credentialsStore.resolveApiId(config.initialApiId)
    private var activeApiHash: String = credentialsStore.resolveApiHash(config.initialApiHash)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Initializing)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _networkState = MutableStateFlow(NetworkSyncState.CONNECTING)
    val networkState: StateFlow<NetworkSyncState> = _networkState.asStateFlow()

    private val _updates = MutableSharedFlow<TdApi.Update>(
        replay = 0,
        extraBufferCapacity = 512,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val updates: SharedFlow<TdApi.Update> = _updates.asSharedFlow()

    init {
        actorScope.launch {
            bootstrapClient()
        }
    }

    /**
     * Saves user-entered my.telegram.org credentials right inside the installed APK and starts TDLib.
     */
    fun applyRuntimeApiCredentials(apiId: Int, apiHash: String) {
        actorScope.launch {
            credentialsStore.save(apiId, apiHash)
            activeApiId = apiId
            activeApiHash = apiHash.trim()
            if (client == null) {
                bootstrapClient()
            }
        }
    }

    private fun ensureNativeLibraryLoaded(): Boolean {
        if (nativeLoaded.get()) return true
        return try {
            // Optional OpenSSL shared libs if TDLib was built with dynamic crypto
            runCatching { System.loadLibrary("cryptox") }
            runCatching { System.loadLibrary("sslx") }
            System.loadLibrary("tdjni")
            Client.execute(TdApi.SetLogVerbosityLevel(1))
            Client.execute(TdApi.SetLogStream(TdApi.LogStreamEmpty()))
            nativeLoaded.set(true)
            true
        } catch (error: Throwable) {
            _authState.value = AuthState.MissingNativeBinary(
                reason = error.message ?: "libtdjni.so (arm64-v8a) отсутствует в APK",
            )
            false
        }
    }

    private fun bootstrapClient() {
        if (activeApiId <= 0 || activeApiHash.isBlank()) {
            _authState.value = AuthState.MissingApiCredentials(
                instructions = "Введите ваш API ID и API Hash с my.telegram.org (один раз при первом запуске).",
            )
            return
        }
        if (!ensureNativeLibraryLoaded()) return

        config.databaseDir.mkdirs()
        config.filesDir.mkdirs()

        val newClient = Client.create(
            /* updateHandler = */ ::onTdLibObjectReceived,
            /* updateExceptionHandler = */ { },
            /* defaultExceptionHandler = */ { },
        )
        client = newClient
        applyZeroBloatEngineOptions(newClient)
    }

    private fun applyZeroBloatEngineOptions(activeClient: Client) {
        val noop = Client.ResultHandler { }
        activeClient.send(
            TdApi.SetOption("disable_animated_emoji", TdApi.OptionValueBoolean(true)),
            noop,
        )
        activeClient.send(
            TdApi.SetOption("disable_contact_registered_notifications", TdApi.OptionValueBoolean(true)),
            noop,
        )
        activeClient.send(
            TdApi.SetOption("use_quick_ack", TdApi.OptionValueBoolean(true)),
            noop,
        )
        activeClient.send(
            TdApi.SetOption("notification_group_count_max", TdApi.OptionValueInteger(0)),
            noop,
        )
    }

    private fun onTdLibObjectReceived(obj: TdApi.Object) {
        if (obj !is TdApi.Update) return
        if (isZeroBloatFilteredUpdate(obj)) return

        when (obj) {
            is TdApi.UpdateAuthorizationState -> {
                actorScope.launch {
                    handleAuthorizationState(obj.authorizationState)
                }
            }
            is TdApi.UpdateConnectionState -> {
                _networkState.value = mapConnectionState(obj.state)
            }
            else -> {
                _updates.tryEmit(obj)
            }
        }
    }

    private fun isZeroBloatFilteredUpdate(update: TdApi.Update): Boolean {
        val name = update.javaClass.simpleName
        return name.startsWith("UpdateStory") ||
            name.startsWith("UpdateChatActiveStories") ||
            name.startsWith("UpdateOwnedStarCount") ||
            name.startsWith("UpdateStarRevenue") ||
            name.startsWith("UpdateGift") ||
            name.startsWith("UpdateWebApp") ||
            name.startsWith("UpdateAttachmentMenuBots") ||
            name.startsWith("UpdateAnimatedEmoji")
    }

    private suspend fun handleAuthorizationState(state: TdApi.AuthorizationState?) {
        when (state) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                _authState.value = AuthState.Initializing
                sendTdlibParameters()
            }
            is TdApi.AuthorizationStateWaitPhoneNumber -> {
                _authState.value = AuthState.WaitPhoneNumber
            }
            is TdApi.AuthorizationStateWaitCode -> {
                val info = state.codeInfo
                _authState.value = AuthState.WaitCode(
                    phoneNumber = info?.phoneNumber.orEmpty(),
                    codeLength = extractCodeLength(info?.type),
                    deliveryChannel = mapDeliveryChannel(info?.type),
                    nextDeliveryChannel = info?.nextType?.let(::mapDeliveryChannel),
                    timeoutSeconds = info?.timeout ?: 0,
                )
            }
            is TdApi.AuthorizationStateWaitPassword -> {
                _authState.value = AuthState.WaitPassword(
                    passwordHint = state.passwordHint.orEmpty(),
                    hasRecoveryEmailAddress = state.hasRecoveryEmailAddress,
                    recoveryEmailPattern = state.recoveryEmailAddressPattern.orEmpty(),
                )
            }
            is TdApi.AuthorizationStateReady -> {
                _authState.value = AuthState.Ready
            }
            is TdApi.AuthorizationStateLoggingOut,
            is TdApi.AuthorizationStateClosing,
            -> {
                _authState.value = AuthState.Closing
            }
            is TdApi.AuthorizationStateClosed -> {
                _authState.value = AuthState.Closed
                client = null
                bootstrapClient()
            }
            else -> Unit
        }
    }

    private suspend fun sendTdlibParameters() {
        val params = TdApi.SetTdlibParameters().apply {
            useTestDc = config.useTestDc
            databaseDirectory = config.databaseDir.absolutePath
            filesDirectory = config.filesDir.absolutePath
            databaseEncryptionKey = ByteArray(0)
            useFileDatabase = true
            useChatInfoDatabase = true
            useMessageDatabase = true
            useSecretChats = false
            apiId = activeApiId
            apiHash = activeApiHash
            systemLanguageCode = config.systemLanguageCode
            deviceModel = config.deviceModel
            systemVersion = config.systemVersion
            applicationVersion = config.appVersion
        }
        runCatching { send(params) }
    }

    suspend fun <R : TdApi.Object> send(query: TdApi.Function<R>): R =
        withContext(dispatchers.tdlibActor) {
            val activeClient = client
                ?: throw TdLibException(-1, "TDLib client is not initialized")

            suspendCancellableCoroutine { continuation ->
                activeClient.send(
                    query,
                    { result ->
                        if (!continuation.isActive) return@send
                        if (result is TdApi.Error) {
                            continuation.resumeWithException(
                                TdLibException(result.code, result.message.orEmpty()),
                            )
                        } else {
                            @Suppress("UNCHECKED_CAST")
                            continuation.resume(result as R)
                        }
                    },
                    { throwable ->
                        if (continuation.isActive) {
                            continuation.resumeWithException(
                                TdLibException(-2, throwable.message ?: "Native JNI dispatch failure"),
                            )
                        }
                    },
                )
            }
        }

    fun sendFireAndForget(query: TdApi.Function<*>) {
        val activeClient = client ?: return
        activeClient.send(query) { }
    }

    suspend fun submitPhoneNumber(rawPhoneNumber: String) {
        val sanitized = buildString(rawPhoneNumber.length) {
            for (ch in rawPhoneNumber) {
                if (ch.isDigit() || ch == '+') append(ch)
            }
        }
        val req = TdApi.SetAuthenticationPhoneNumber().apply {
            phoneNumber = sanitized
            settings = null
        }
        send(req)
    }

    suspend fun submitVerificationCode(code: String) {
        send(TdApi.CheckAuthenticationCode(code.trim()))
    }

    suspend fun resendVerificationCode() {
        send(TdApi.ResendAuthenticationCode())
    }

    suspend fun submitTwoFactorPassword(password: String) {
        send(TdApi.CheckAuthenticationPassword(password))
    }

    suspend fun logOut() {
        send(TdApi.LogOut())
    }

    private fun extractCodeLength(type: TdApi.AuthenticationCodeType?): Int = when (type) {
        is TdApi.AuthenticationCodeTypeTelegramMessage -> type.length
        is TdApi.AuthenticationCodeTypeSms -> type.length
        is TdApi.AuthenticationCodeTypeCall -> type.length
        is TdApi.AuthenticationCodeTypeMissedCall -> type.length
        else -> 5
    }

    private fun mapDeliveryChannel(type: TdApi.AuthenticationCodeType?): CodeDeliveryChannel = when (type) {
        is TdApi.AuthenticationCodeTypeTelegramMessage -> CodeDeliveryChannel.TELEGRAM_APP
        is TdApi.AuthenticationCodeTypeSms -> CodeDeliveryChannel.SMS
        is TdApi.AuthenticationCodeTypeCall -> CodeDeliveryChannel.PHONE_CALL
        is TdApi.AuthenticationCodeTypeFlashCall -> CodeDeliveryChannel.FLASH_CALL
        is TdApi.AuthenticationCodeTypeMissedCall -> CodeDeliveryChannel.MISSED_CALL
        else -> CodeDeliveryChannel.UNKNOWN
    }

    private fun mapConnectionState(state: TdApi.ConnectionState?): NetworkSyncState = when (state) {
        is TdApi.ConnectionStateWaitingForNetwork -> NetworkSyncState.WAITING_FOR_NETWORK
        is TdApi.ConnectionStateConnecting,
        is TdApi.ConnectionStateConnectingToProxy,
        -> NetworkSyncState.CONNECTING
        is TdApi.ConnectionStateUpdating -> NetworkSyncState.UPDATING
        is TdApi.ConnectionStateReady -> NetworkSyncState.READY
        else -> NetworkSyncState.CONNECTING
    }
}
