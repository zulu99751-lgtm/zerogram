Place prebuilt Android arm64-v8a TDLib shared library binaries in this directory:
  1. libtdjni.so        (built from https://github.com/tdlib/td/tree/master/example/android)
  2. libcryptox.so      (only if OpenSSL was linked dynamically instead of statically)
  3. libsslx.so         (only if OpenSSL was linked dynamically instead of statically)

And replace core/tdlib/src/main/java/org/drinkless/tdlib/{Client.java,TdApi.java}
with the full generated Java sources matching your exact libtdjni.so build.
