package app.zerogram.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import androidx.paging.map
import app.zerogram.core.common.FastFormatters
import app.zerogram.core.tdlib.ChatMessagesRepository
import app.zerogram.core.tdlib.model.ChatMessageItem
import app.zerogram.core.tdlib.model.DomainMessageContent
import app.zerogram.core.tdlib.model.OutgoingDeliveryStatus
import kotlinx.collections.immutable.persistentSetOf
import kotlinx.collections.immutable.toImmutableList
import kotlinx.collections.immutable.toImmutableSet
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(
    private val chatId: Long,
    initialTitle: String,
    private val chatMessagesRepository: ChatMessagesRepository,
    private val voicePlayerController: VoicePlayerController,
) : ViewModel() {

    private val inputText = MutableStateFlow("")
    private val tappedStickers = MutableStateFlow(persistentSetOf<Long>())

    private val instantSeed = chatMessagesRepository
        .getInstantSeedMessages(chatId)
        .map(::mapToBubbleUi)
        .toImmutableList()

    val pagedMessages: Flow<PagingData<MessageBubbleUi>> = chatMessagesRepository
        .pagedHistoryFlow(chatId)
        .map { pagingData -> pagingData.map(::mapToBubbleUi) }
        .cachedIn(viewModelScope)

    val uiState: StateFlow<ChatUiState> = combine(
        inputText,
        voicePlayerController.state,
        tappedStickers,
    ) { draft, voice, stickers ->
        ChatUiState(
            chatId = chatId,
            title = initialTitle,
            inputText = draft,
            instantSeedMessages = instantSeed,
            voicePlayback = voice,
            tappedStickerIds = stickers,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = ChatUiState(
            chatId = chatId,
            title = initialTitle,
            instantSeedMessages = instantSeed,
        ),
    )

    init {
        chatMessagesRepository.openChatSession(chatId)
    }

    override fun onCleared() {
        chatMessagesRepository.closeChatSession(chatId)
        voicePlayerController.stopAndRelease()
        super.onCleared()
    }

    fun onIntent(intent: ChatIntent) {
        when (intent) {
            is ChatIntent.InputChanged -> {
                inputText.value = intent.text
            }
            ChatIntent.SendText -> {
                val textToSend = inputText.value.trim()
                if (textToSend.isEmpty()) return
                inputText.value = ""
                viewModelScope.launch {
                    runCatching { chatMessagesRepository.sendTextMessage(chatId, textToSend) }
                }
            }
            is ChatIntent.SendPickedPhoto -> {
                val caption = inputText.value.trim()
                inputText.value = ""
                viewModelScope.launch {
                    runCatching {
                        chatMessagesRepository.sendPhotoUri(chatId, intent.uri, caption)
                    }
                }
            }
            is ChatIntent.ClickVoice -> {
                val path = intent.localPath
                if (path.isNullOrBlank()) {
                    chatMessagesRepository.requestMediaDownload(intent.fileId, highPriority = true)
                } else {
                    voicePlayerController.togglePlayPause(intent.messageId, path)
                }
            }
            ChatIntent.CycleVoiceSpeed -> {
                voicePlayerController.cycleSpeed()
            }
            is ChatIntent.ClickSticker -> {
                if (!intent.isAnimatedFormat) return
                val current = tappedStickers.value
                val next = if (current.contains(intent.messageId)) {
                    (current - intent.messageId).toImmutableSet()
                } else {
                    chatMessagesRepository.requestMediaDownload(intent.stickerFileId, highPriority = true)
                    (current + intent.messageId).toImmutableSet()
                }
                tappedStickers.value = next
            }
            is ChatIntent.ClickDocument -> {
                if (intent.localPath.isNullOrBlank()) {
                    chatMessagesRepository.requestMediaDownload(intent.fileId, highPriority = true)
                }
            }
            is ChatIntent.ClickPhoto -> {
                if (intent.localPath.isNullOrBlank()) {
                    chatMessagesRepository.requestMediaDownload(intent.fileId, highPriority = true)
                }
            }
        }
    }

    companion object {
        fun mapToBubbleUi(item: ChatMessageItem): MessageBubbleUi {
            val badge = when (item.deliveryStatus) {
                OutgoingDeliveryStatus.NONE -> ""
                OutgoingDeliveryStatus.PENDING -> " ⏱"
                OutgoingDeliveryStatus.SENT_UNREAD -> " ✓"
                OutgoingDeliveryStatus.READ -> " ✓✓"
                OutgoingDeliveryStatus.FAILED -> " !"
            }
            val media = when (val c = item.content) {
                is DomainMessageContent.Text -> BubbleMediaUi.Text(c.body)
                is DomainMessageContent.Photo -> BubbleMediaUi.Photo(
                    fileId = c.fileId,
                    localPath = c.localPath,
                    aspectRatio = (c.width.toFloat() / c.height.coerceAtLeast(1).toFloat())
                        .coerceIn(0.55f, 1.9f),
                    caption = c.caption,
                    isDownloading = c.isDownloading,
                )
                is DomainMessageContent.Voice -> BubbleMediaUi.Voice(
                    fileId = c.fileId,
                    localPath = c.localPath,
                    durationSeconds = c.durationSec,
                    durationLabel = FastFormatters.formatDurationSeconds(c.durationSec),
                    waveformSamples = c.waveformSamples,
                    isDownloading = c.isDownloading,
                )
                is DomainMessageContent.Sticker -> BubbleMediaUi.Sticker(
                    stickerFileId = c.stickerFileId,
                    staticPreviewFileId = c.staticPreviewFileId,
                    staticPreviewLocalPath = c.staticPreviewLocalPath,
                    animatedLocalPath = c.animatedLocalPath,
                    emoji = c.emoji,
                    isAnimatedFormat = c.isAnimatedFormat,
                )
                is DomainMessageContent.DocumentFile -> BubbleMediaUi.DocumentFile(
                    fileId = c.fileId,
                    localPath = c.localPath,
                    fileName = c.fileName,
                    sizeLabel = c.sizeLabel,
                    isDownloading = c.isDownloading,
                )
                is DomainMessageContent.VideoNoteStatic -> BubbleMediaUi.VideoNoteTappedOnly(
                    durationLabel = FastFormatters.formatDurationSeconds(c.durationSec),
                )
                is DomainMessageContent.Unsupported -> BubbleMediaUi.Text(c.label)
            }

            return MessageBubbleUi(
                id = item.id,
                senderName = item.senderName,
                isOutgoing = item.isOutgoing,
                formattedTime = item.formattedTime,
                statusBadge = badge,
                media = media,
            )
        }

        fun factory(
            chatId: Long,
            initialTitle: String,
            chatMessagesRepository: ChatMessagesRepository,
            voicePlayerController: VoicePlayerController,
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return ChatViewModel(
                    chatId = chatId,
                    initialTitle = initialTitle,
                    chatMessagesRepository = chatMessagesRepository,
                    voicePlayerController = voicePlayerController,
                ) as T
            }
        }
    }
}
