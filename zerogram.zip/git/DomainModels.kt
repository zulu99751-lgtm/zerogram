package app.zerogram.core.tdlib.model

import kotlinx.collections.immutable.ImmutableList

data class ChatFolderTab(
    val folderId: Int?, // null == ChatListMain ("Все чаты")
    val title: String,
    val unreadChatsCount: Int,
)

data class DialogSummary(
    val chatId: Long,
    val title: String,
    val avatarInitials: String,
    val avatarColorArgb: Int,
    val avatarFileId: Int?,
    val avatarLocalPath: String?,
    val previewText: String,
    val isDraft: Boolean,
    val formattedTime: String,
    val unreadCount: Int,
    val isPinned: Boolean,
    val showOutgoingStatus: Boolean,
    val isOutgoingRead: Boolean,
)

enum class OutgoingDeliveryStatus {
    NONE,
    PENDING,
    SENT_UNREAD,
    READ,
    FAILED,
}

sealed interface DomainMessageContent {
    data class Text(
        val body: String,
    ) : DomainMessageContent

    data class Photo(
        val fileId: Int,
        val localPath: String?,
        val width: Int,
        val height: Int,
        val caption: String,
        val isDownloading: Boolean,
    ) : DomainMessageContent

    data class Voice(
        val fileId: Int,
        val localPath: String?,
        val durationSec: Int,
        val waveformSamples: ImmutableList<Float>,
        val isDownloading: Boolean,
    ) : DomainMessageContent

    data class Sticker(
        val stickerFileId: Int,
        val staticPreviewFileId: Int,
        val staticPreviewLocalPath: String?,
        val animatedLocalPath: String?,
        val emoji: String,
        val width: Int,
        val height: Int,
        val isAnimatedFormat: Boolean,
    ) : DomainMessageContent

    data class DocumentFile(
        val fileId: Int,
        val localPath: String?,
        val fileName: String,
        val sizeLabel: String,
        val isDownloading: Boolean,
    ) : DomainMessageContent

    data class VideoNoteStatic(
        val durationSec: Int,
    ) : DomainMessageContent

    data class Unsupported(
        val label: String,
    ) : DomainMessageContent
}

data class ChatMessageItem(
    val id: Long,
    val chatId: Long,
    val senderName: String?,
    val isOutgoing: Boolean,
    val formattedTime: String,
    val deliveryStatus: OutgoingDeliveryStatus,
    val content: DomainMessageContent,
)
