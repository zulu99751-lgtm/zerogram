package app.zerogram.baselineprofile

import androidx.benchmark.macro.junit4.BaselineProfileRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BaselineProfileGenerator {

    @get:Rule
    val rule = BaselineProfileRule()

    @Test
    fun generateFullCriticalJourneyProfile() {
        rule.collect(
            packageName = "app.zerogram",
            includeInStartupProfile = true,
        ) {
            pressHome()
            startActivityAndWait()
            device.waitForIdle()
            // Pre-compile fling & Compose layout code paths
            val rootBounds = device.displayWidth to device.displayHeight
            if (rootBounds.first > 0 && rootBounds.second > 0) {
                device.swipe(
                    rootBounds.first / 2,
                    (rootBounds.second * 3) / 4,
                    rootBounds.first / 2,
                    rootBounds.second / 4,
                    12,
                )
            }
        }
    }
}
