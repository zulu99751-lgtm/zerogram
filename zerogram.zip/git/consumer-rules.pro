# Preserve JNI entrypoints & TL constructors instantiated natively by libtdjni.so
-keep class org.drinkless.tdlib.Client {
    native <methods>;
    private static void onResult(long, org.drinkless.tdlib.TdApi$Object);
}
-keep interface org.drinkless.tdlib.Client$ResultHandler { *; }
-keep interface org.drinkless.tdlib.Client$ExceptionHandler { *; }
-keep class org.drinkless.tdlib.Client$ExecutionException { *; }
-keep class org.drinkless.tdlib.TdApi { *; }
-keep class org.drinkless.tdlib.TdApi$* {
    <init>(...);
    <fields>;
}
