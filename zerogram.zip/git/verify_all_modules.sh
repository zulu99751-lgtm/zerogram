#!/usr/bin/env bash
set -euo pipefail

echo "=== ZeroGram Full Project Build Check (Steps 1-3) ==="

SO_FILE="core/tdlib/src/main/jniLibs/arm64-v8a/libtdjni.so"
if [[ ! -f "$SO_FILE" ]]; then
  echo "[WARN] $SO_FILE is not placed yet."
  echo "       Put prebuilt arm64-v8a libtdjni.so & matching TdApi.java before running on device."
fi

./gradlew :core:common:assembleDebug \
          :core:designsystem:assembleDebug \
          :core:tdlib:assembleDebug \
          :feature:auth:assembleDebug \
          :feature:chats:assembleDebug \
          :feature:chat:assembleDebug \
          :app:assembleDebug \
          :app:assembleRelease

echo "=== Debug & R8 Release Builds Succeeded ==="
