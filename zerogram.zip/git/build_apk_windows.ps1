$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

$ToolsDir = Join-Path $PWD ".local-build-tools"
New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null

# 1. Check or download portable Gradle 8.14
$GradleBin = Get-Command gradle -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source
if (-not $GradleBin) {
    $GradleHome = Join-Path $ToolsDir "gradle-8.14"
    $GradleBat = Join-Path $GradleHome "bin\gradle.bat"
    if (-not (Test-Path $GradleBat)) {
        Write-Host "[1/3] Скачивание портативного Gradle 8.14..." -ForegroundColor Cyan
        $GradleZip = Join-Path $ToolsDir "gradle.zip"
        Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-8.14-bin.zip" -OutFile $GradleZip
        Expand-Archive -Path $GradleZip -DestinationPath $ToolsDir -Force
        Remove-Item $GradleZip -Force
    }
    $GradleBin = $GradleBat
}

# 2. Check ANDROID_HOME or standard Windows Android SDK path
$SdkDir = $env:ANDROID_HOME
if (-not $SdkDir) {
    $DefaultWinSdk = Join-Path $env:LOCALAPPDATA "Android\Sdk"
    if (Test-Path $DefaultWinSdk) {
        $SdkDir = $DefaultWinSdk
    }
}

if (-not $SdkDir -or -not (Test-Path $SdkDir)) {
    Write-Host "[2/3] Скачивание портативного Android Command-Line Tools (SDK 36)..." -ForegroundColor Cyan
    $SdkDir = Join-Path $ToolsDir "android-sdk"
    $CmdToolsZip = Join-Path $ToolsDir "cmdline-tools.zip"
    Invoke-WebRequest -Uri "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip" -OutFile $CmdToolsZip
    $ExtractTmp = Join-Path $ToolsDir "cmdline-tmp"
    Expand-Archive -Path $CmdToolsZip -DestinationPath $ExtractTmp -Force
    $LatestDir = Join-Path $SdkDir "cmdline-tools\latest"
    New-Item -ItemType Directory -Force -Path $LatestDir | Out-Null
    Copy-Item -Path (Join-Path $ExtractTmp "cmdline-tools\*") -Destination $LatestDir -Recurse -Force
    Remove-Item $CmdToolsZip, $ExtractTmp -Recurse -Force

    $SdkManager = Join-Path $LatestDir "bin\sdkmanager.bat"
    "y`ny`ny`ny`ny`n" | & $SdkManager --sdk_root="$SdkDir" "platform-tools" "platforms;android-36" "build-tools;36.0.0"
}

$EscapedSdk = $SdkDir.Replace("\", "\\")
Set-Content -Path "local.properties" -Value "sdk.dir=$EscapedSdk" -Encoding UTF8

Write-Host "[3/3] Сборка подписанного R8 Release APK..." -ForegroundColor Green
& $GradleBin :app:assembleRelease --no-daemon

$OutDir = Join-Path $PWD "dist"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$ReleaseApk = Join-Path $PWD "app\build\outputs\apk\release\app-release.apk"
$TargetApk = Join-Path $OutDir "ZeroGram-arm64-v8a-release.apk"
Copy-Item $ReleaseApk $TargetApk -Force

Write-Host ""
Write-Host "ГОТОВО! APK сохранен в: $TargetApk" -ForegroundColor Green
explorer.exe /select,"$TargetApk"
