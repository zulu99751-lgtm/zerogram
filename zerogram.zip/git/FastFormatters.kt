package app.zerogram.core.common

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Allocation-conscious formatters run on background threads when building UI models,
 * never inside @Composable layout/draw passes.
 */
object FastFormatters {
    private val avatarPalette = intArrayOf(
        0xFF2AABEE.toInt(),
        0xFF229ED9.toInt(),
        0xFF34C759.toInt(),
        0xFFFF9500.toInt(),
        0xFFAF52DE.toInt(),
        0xFFFF3B30.toInt(),
        0xFF00C7BE.toInt(),
    )

    fun avatarColorForId(id: Long): Int {
        val idx = ((id xor (id ushr 32)).toInt() and 0x7FFFFFFF) % avatarPalette.size
        return avatarPalette[idx]
    }

    fun initialsForTitle(title: String): String {
        val trimmed = title.trim()
        if (trimmed.isEmpty()) return "?"
        val spaceIdx = trimmed.indexOf(' ')
        return if (spaceIdx > 0 && spaceIdx + 1 < trimmed.length) {
            "${trimmed[0].uppercaseChar()}${trimmed[spaceIdx + 1].uppercaseChar()}"
        } else {
            trimmed.take(2).uppercase()
        }
    }

    fun formatUnixTimeShort(epochSeconds: Int, zoneId: ZoneId = ZoneId.systemDefault()): String {
        if (epochSeconds <= 0) return ""
        val dt = Instant.ofEpochSecond(epochSeconds.toLong()).atZone(zoneId)
        val today = LocalDate.now(zoneId)
        return if (dt.toLocalDate() == today) {
            twoDigits(dt.hour) + ":" + twoDigits(dt.minute)
        } else {
            twoDigits(dt.dayOfMonth) + "." + twoDigits(dt.monthValue)
        }
    }

    fun formatMessageClock(epochSeconds: Int, zoneId: ZoneId = ZoneId.systemDefault()): String {
        if (epochSeconds <= 0) return ""
        val dt = Instant.ofEpochSecond(epochSeconds.toLong()).atZone(zoneId)
        return twoDigits(dt.hour) + ":" + twoDigits(dt.minute)
    }

    fun formatDurationSeconds(totalSeconds: Int): String {
        val safe = totalSeconds.coerceAtLeast(0)
        val minutes = safe / 60
        val seconds = safe % 60
        return "$minutes:${twoDigits(seconds)}"
    }

    fun formatByteSize(bytes: Long): String {
        if (bytes <= 0L) return "0 Б"
        val kb = 1024L
        val mb = kb * 1024L
        return when {
            bytes >= mb -> {
                val whole = bytes / mb
                val tenth = ((bytes % mb) * 10) / mb
                "$whole.$tenth МБ"
            }
            bytes >= kb -> "${bytes / kb} КБ"
            else -> "$bytes Б"
        }
    }

    private fun twoDigits(value: Int): String =
        if (value < 10) "0$value" else value.toString()
}
