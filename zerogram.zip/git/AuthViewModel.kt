package app.zerogram.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import app.zerogram.core.tdlib.TdLibManager
import app.zerogram.core.tdlib.model.AuthState
import app.zerogram.core.tdlib.model.TdLibException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AuthViewModel(
    private val tdLibManager: TdLibManager,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            tdLibManager.authState.collect(::onEngineAuthStateChanged)
        }
    }

    private fun onEngineAuthStateChanged(authState: AuthState) {
        when (authState) {
            AuthState.Initializing,
            AuthState.Closing,
            AuthState.Closed,
            -> {
                _uiState.update { it.copy(step = AuthStep.INITIALIZING, isLoading = true) }
            }
            is AuthState.MissingApiCredentials -> {
                _uiState.update {
                    it.copy(
                        step = AuthStep.API_CREDENTIALS_INPUT,
                        isLoading = false,
                        setupDiagnosticMessage = authState.instructions,
                    )
                }
            }
            is AuthState.MissingNativeBinary -> {
                _uiState.update {
                    it.copy(
                        step = AuthStep.SETUP_REQUIRED,
                        isLoading = false,
                        setupDiagnosticMessage = authState.reason,
                    )
                }
            }
            AuthState.WaitPhoneNumber -> {
                _uiState.update {
                    it.copy(
                        step = AuthStep.PHONE_NUMBER,
                        isLoading = false,
                        codeInput = "",
                        errorMessage = null,
                    )
                }
            }
            is AuthState.WaitCode -> {
                _uiState.update {
                    it.copy(
                        step = AuthStep.VERIFICATION_CODE,
                        phoneInput = authState.phoneNumber.ifBlank { it.phoneInput },
                        expectedCodeLength = authState.codeLength.coerceAtLeast(4),
                        deliveryChannel = authState.deliveryChannel,
                        codeInput = "",
                        isLoading = false,
                        errorMessage = null,
                    )
                }
            }
            is AuthState.WaitPassword -> {
                _uiState.update {
                    it.copy(
                        step = AuthStep.TWO_FACTOR_PASSWORD,
                        passwordHint = authState.passwordHint,
                        passwordInput = "",
                        isLoading = false,
                        errorMessage = null,
                    )
                }
            }
            AuthState.Ready -> {
                _uiState.update { it.copy(isLoading = false, errorMessage = null) }
            }
        }
    }

    fun onIntent(intent: AuthIntent) {
        when (intent) {
            is AuthIntent.ApiIdChanged -> {
                _uiState.update {
                    it.copy(apiIdInput = intent.value.filter(Char::isDigit), errorMessage = null)
                }
            }
            is AuthIntent.ApiHashChanged -> {
                _uiState.update {
                    it.copy(apiHashInput = intent.value.trim(), errorMessage = null)
                }
            }
            AuthIntent.SaveApiCredentials -> {
                val id = _uiState.value.apiIdInput.toIntOrNull() ?: 0
                val hash = _uiState.value.apiHashInput.trim()
                if (id <= 0 || hash.length < 16) {
                    _uiState.update {
                        it.copy(errorMessage = "Укажите корректный числовой API ID и 32-символьный API Hash")
                    }
                    return
                }
                _uiState.update { it.copy(isLoading = true, errorMessage = null) }
                tdLibManager.applyRuntimeApiCredentials(id, hash)
            }

            is AuthIntent.PhoneChanged -> {
                val filtered = buildString(intent.value.length) {
                    for (i in intent.value.indices) {
                        val c = intent.value[i]
                        if (c.isDigit() || (i == 0 && c == '+')) append(c)
                    }
                }
                _uiState.update { it.copy(phoneInput = filtered, errorMessage = null) }
            }
            AuthIntent.SubmitPhone -> submitPhone()

            is AuthIntent.CodeChanged -> {
                val digitsOnly = intent.value.filter(Char::isDigit).take(8)
                val targetLen = _uiState.value.expectedCodeLength
                _uiState.update { it.copy(codeInput = digitsOnly, errorMessage = null) }
                if (digitsOnly.length == targetLen && !_uiState.value.isLoading) {
                    submitCode(digitsOnly)
                }
            }
            AuthIntent.SubmitCode -> submitCode(_uiState.value.codeInput)
            AuthIntent.ResendCode -> resendCode()

            is AuthIntent.PasswordChanged -> {
                _uiState.update { it.copy(passwordInput = intent.value, errorMessage = null) }
            }
            AuthIntent.TogglePasswordVisibility -> {
                _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
            }
            AuthIntent.SubmitPassword -> submitPassword()

            AuthIntent.ClearError -> {
                _uiState.update { it.copy(errorMessage = null) }
            }
        }
    }

    private fun submitPhone() {
        val phone = _uiState.value.phoneInput
        if (phone.count(Char::isDigit) < 7) {
            _uiState.update { it.copy(errorMessage = "Введите корректный номер в международном формате") }
            return
        }
        executeAuthAction { tdLibManager.submitPhoneNumber(phone) }
    }

    private fun submitCode(code: String) {
        if (code.isBlank()) return
        executeAuthAction { tdLibManager.submitVerificationCode(code) }
    }

    private fun resendCode() {
        executeAuthAction { tdLibManager.resendVerificationCode() }
    }

    private fun submitPassword() {
        val password = _uiState.value.passwordInput
        if (password.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Введите облачный пароль 2FA") }
            return
        }
        executeAuthAction { tdLibManager.submitTwoFactorPassword(password) }
    }

    private inline fun executeAuthAction(crossinline block: suspend () -> Unit) {
        if (_uiState.value.isLoading) return
        _uiState.update { it.copy(isLoading = true, errorMessage = null) }
        viewModelScope.launch {
            try {
                block()
            } catch (e: TdLibException) {
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = formatTdLibAuthError(e))
                }
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = t.message ?: "Ошибка авторизации")
                }
            }
        }
    }

    private fun formatTdLibAuthError(error: TdLibException): String {
        val msg = error.message
        return when {
            msg.contains("PHONE_NUMBER_INVALID", ignoreCase = true) -> "Неверный формат номера телефона."
            msg.contains("PHONE_CODE_INVALID", ignoreCase = true) -> "Неверный код подтверждения."
            msg.contains("PHONE_CODE_EXPIRED", ignoreCase = true) -> "Код истек. Запросите новый код."
            msg.contains("PASSWORD_HASH_INVALID", ignoreCase = true) -> "Неверный облачный пароль 2FA."
            msg.contains("FLOOD_WAIT", ignoreCase = true) -> "Слишком много попыток. Повторите позже."
            else -> msg
        }
    }

    companion object {
        fun factory(tdLibManager: TdLibManager): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AuthViewModel(tdLibManager) as T
                }
            }
    }
}
