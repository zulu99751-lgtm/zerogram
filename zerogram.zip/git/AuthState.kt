package app.zerogram.core.tdlib.model

enum class CodeDeliveryChannel {
    TELEGRAM_APP,
    SMS,
    PHONE_CALL,
    FLASH_CALL,
    MISSED_CALL,
    UNKNOWN,
}

sealed interface AuthState {
    data object Initializing : AuthState

    data class MissingNativeBinary(
        val reason: String,
    ) : AuthState

    data class MissingApiCredentials(
        val instructions: String,
    ) : AuthState

    data object WaitPhoneNumber : AuthState

    data class WaitCode(
        val phoneNumber: String,
        val codeLength: Int,
        val deliveryChannel: CodeDeliveryChannel,
        val nextDeliveryChannel: CodeDeliveryChannel?,
        val timeoutSeconds: Int,
    ) : AuthState

    data class WaitPassword(
        val passwordHint: String,
        val hasRecoveryEmailAddress: Boolean,
        val recoveryEmailPattern: String,
    ) : AuthState

    data object Ready : AuthState

    data object Closing : AuthState

    data object Closed : AuthState
}

enum class NetworkSyncState {
    WAITING_FOR_NETWORK,
    CONNECTING,
    UPDATING,
    READY,
}

class TdLibException(
    val code: Int,
    override val message: String,
) : Exception("TDLib error [$code]: $message")
