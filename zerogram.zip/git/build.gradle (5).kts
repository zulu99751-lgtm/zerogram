import java.util.Properties

plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
}

val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) {
        file.inputStream().use { load(it) }
    }
}

val tdlibApiId: Int = (
    localProps.getProperty("TDLIB_API_ID")
        ?: providers.gradleProperty("TDLIB_API_ID").orNull
        ?: System.getenv("TDLIB_API_ID")
        ?: "0"
).toIntOrNull() ?: 0

val tdlibApiHash: String = (
    localProps.getProperty("TDLIB_API_HASH")
        ?: providers.gradleProperty("TDLIB_API_HASH").orNull
        ?: System.getenv("TDLIB_API_HASH")
        ?: ""
)

android {
    namespace = "app.zerogram.core.tdlib"
    compileSdk = 36

    defaultConfig {
        minSdk = 26

        // Strict arm64-v8a ABI cuts unused x86/x86_64/armv7 native weight
        ndk {
            abiFilters += "arm64-v8a"
        }

        consumerProguardFiles("consumer-rules.pro")

        buildConfigField("int", "TDLIB_API_ID", tdlibApiId.toString())
        buildConfigField("String", "TDLIB_API_HASH", "\"$tdlibApiHash\"")
    }

    sourceSets {
        getByName("main") {
            jniLibs.srcDirs("src/main/jniLibs")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(projects.core.common)
    implementation(libs.androidx.core.ktx)
    api(libs.androidx.paging.common)
}
